# TopCaptions — Windows Source Bundle

This folder is the complete Windows source distribution for the latest TopCaptions build. It contains the CEP panel source, Premiere ExtendScript files, the Python transcription backend, the automatic-cut integration, licensing and shared-trial code, installer sources, and the audio export preset.

## Included components

| Path | Contents |
|---|---|
| `CSXS/` | Adobe CEP extension manifest |
| `index.html`, `css/`, `js/`, `jsx/` | Panel interface, licensing, captioning and automatic-cut source |
| `backend/` | Python `faster-whisper` transcription worker and dependencies |
| `presets/HebrewCaptionsWAV.epr` | Bundled Premiere Pro Waveform Audio export preset |
| `models/ivrit-ai--whisper-large-v3-turbo-ct2/` | Complete official `ivrit-ai/whisper-large-v3-turbo-ct2` model cache, Apache-2.0 |
| `LICENSE_SERVER_SETUP.gs` | Google Apps Script server implementation for shared trial usage and product-key activation |
| `TopCaptions.iss`, `setup_windows*.bat` | Windows installer source and setup scripts |
| `logo.ico` | Windows installer icon |

## Model source

The included model is `ivrit-ai/whisper-large-v3-turbo-ct2`, the exact `faster-whisper` repository requested by `backend/caption_engine.py`. It was downloaded from the official model repository and has an Apache-2.0 license.

> The model adds approximately 1.6 GB to this source distribution.

## Windows build

Compile `TopCaptions.iss` with Inno Setup to build the Windows installer. The installer script copies the CEP extension and installs the Python transcription dependencies for the current user.

## License service

The panel routes trial and activation traffic to the configured Google Apps Script Web App endpoint. The public endpoint URL is embedded in `js/license-platform-bridge.js`; the spreadsheet itself and product-key contents are not included in this archive.
