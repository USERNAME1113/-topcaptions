// main.jsx - ExtendScript running inside Premiere Pro.
// Talks to js/main.js via CSInterface.evalScript(). Every function returns a
// JSON string (success or {error: "..."}) since evalScript only passes strings.

// The automatic-cut engine is kept in a focused module, but is loaded through
// this host entry point so hcApplySilenceCuts is available to the CEP panel.
#include "autocut.jsx"

// Caption jobs preserve the selection captured by the panel so export and
// caption-track placement refer to the same timeline range.
var HC_PENDING_CAPTION_RANGE = null;

function jsonOk(obj) {
	obj = obj || {};
	obj.ok = true;
	return JSON.stringify(obj);
}

function jsonErr(message) {
	return JSON.stringify({ ok: false, error: String(message) });
}

/** Info about the active sequence, or an error if none is open. */
function hcGetSequenceInfo() {
	try {
		if (!app.project) return jsonErr("אין פרויקט פתוח");
		var seq = app.project.activeSequence;
		if (!seq) return jsonErr("אין רצף (Sequence) פעיל - פתחו רצף בטיימליין");
		return jsonOk({
			name: seq.name,
			projectPath: app.project.path
		});
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Recursively search a folder (depth-limited) for the first .epr file whose
 *  name contains "Waveform Audio". Returns an fsName string, or null. */
function hcSearchForWaveformPreset(folder, depth) {
	if (!folder || !folder.exists || depth > 9) return null;
	var entries;
	try { entries = folder.getFiles(); } catch (e) { return null; }
	if (!entries) return null;

	// Check files at this level first, preferring the classic 48kHz/16-bit name.
	var firstMatch = null;
	for (var i = 0; i < entries.length; i++) {
		var e = entries[i];
		if (e instanceof File && /waveform audio/i.test(e.name) && /\.epr$/i.test(e.name)) {
			if (/48\s*k?hz.*16.?bit/i.test(e.name)) return e.fsName;
			if (!firstMatch) firstMatch = e.fsName;
		}
	}
	if (firstMatch) return firstMatch;

	// Then recurse into subfolders. Skip a few large, clearly irrelevant
	// Adobe folders to keep this from taking forever on a full Adobe tree.
	var SKIP = /^(Fonts|CCLibraries|CCX Process|Adobe Creative Cloud Experience|Adobe Creative Cloud)$/i;
	for (var j = 0; j < entries.length; j++) {
		var sub = entries[j];
		if (sub instanceof Folder && !SKIP.test(sub.name)) {
			var found = hcSearchForWaveformPreset(sub, depth + 1);
			if (found) return found;
		}
	}
	return null;
}

var hcLastPresetSearchPaths = [];
var hcLastAppPath = "";

// Known-good locations seen in the wild (e.g. Subli's own bundled config) -
// checked first since they're instant, before falling back to a slow
// full-tree search.
var HC_KNOWN_PRESET_CANDIDATES = [
	"C:/Program Files/Adobe/Adobe Premiere Pro 2026/MediaIO/systempresets/3F3F3F3F_57415645/Waveform Audio 48kHz 16-bit.epr",
	"C:/Program Files/Adobe/Adobe Premiere Pro 2025/MediaIO/systempresets/3F3F3F3F_57415645/Waveform Audio 48kHz 16-bit.epr",
	"C:/Program Files/Adobe/Premiere Pro 2025/MediaIO/systempresets/3F3F3F3F_57415645/Waveform Audio 48kHz 16-bit.epr",
	"C:/Program Files/Adobe/Premiere Pro 2026/MediaIO/systempresets/3F3F3F3F_57415645/Waveform Audio 48kHz 16-bit.epr"
];

/** Path to the user-supplied WAV preset bundled with this extension.
 * It is resolved relative to this script, so it works wherever the installer
 * places the CEP extension. This is the default export preset; Premiere's
 * installed presets are used only as a fallback if this file is unavailable. */
function hcBundledPresetPath() {
	try {
		var thisScript = new File($.fileName); // .../jsx/main.jsx
		var extRoot = thisScript.parent.parent; // .../ (extension root)
		var bundled = new File(extRoot.fsName + "/presets/HebrewCaptionsWAV.epr");
		return bundled.exists ? bundled.fsName : null;
	} catch (e) {
		return null;
	}
}

/** Find a WAV export preset shipped with this Premiere Pro install, by
 *  recursively searching the Adobe install roots. This is the primary way
 *  a preset gets found (see hcResolvePreset) - slow, so the result gets
 *  cached by js/main.js to avoid repeating it. */
function hcFindAudioPreset() {
	var tried = [];
	try { hcLastAppPath = String(app.path); } catch (e) { hcLastAppPath = "(app.path unavailable: " + e + ")"; }

	// 0) Try known-good candidate paths first - instant, no folder scan.
	for (var k = 0; k < HC_KNOWN_PRESET_CANDIDATES.length; k++) {
		var candidate = new File(HC_KNOWN_PRESET_CANDIDATES[k]);
		tried.push(candidate.fsName);
		if (candidate.exists) return candidate.fsName;
	}

	var roots = [
		"C:/Program Files/Adobe",
		"C:/Program Files (x86)/Adobe"
	];

	// Custom installs (a different drive, a company-managed install path,
	// etc.) mean the app's real Adobe root isn't necessarily under
	// "C:/Program Files" at all - app.path is the one thing that always
	// reflects where THIS install actually lives, so derive an extra
	// search root from it instead of only ever trying the two hardcoded
	// defaults above.
	try {
		var exeFile = new File(app.path);
		var walker = exeFile.exists ? exeFile.parent : null;
		// Walk up a couple of levels from the executable (past the
		// version-specific app folder) to land on the shared "Adobe" root
		// that also contains MediaIO/systempresets.
		for (var up = 0; up < 3 && walker; up++) {
			if (/[\\\/]Adobe[\\\/]?$/i.test(walker.fsName)) break;
			walker = walker.parent;
		}
		if (walker && walker.exists) {
			var already = false;
			for (var ri = 0; ri < roots.length; ri++) {
				if (roots[ri].toLowerCase() === walker.fsName.toLowerCase()) { already = true; break; }
			}
			if (!already) roots.unshift(walker.fsName);
		}
	} catch (e) { /* non-fatal - just skip the derived root */ }

	for (var r = 0; r < roots.length; r++) {
		var rootFolder = new Folder(roots[r]);
		if (!rootFolder.exists) continue;
		tried.push(rootFolder.fsName);
		var hit = hcSearchForWaveformPreset(rootFolder, 0);
		if (hit) return hit;
	}

	hcLastPresetSearchPaths = tried;
	return null;
}

/** Resolve an EPR without requiring any user configuration:
 *  1) the supplied, bundled HebrewCaptions WAV preset
 *  2) a previously cached custom path, if present
 *  3) a compatible preset already installed with Premiere Pro */
function hcResolvePreset(cachedPreset) {
	var bundled = hcBundledPresetPath();
	if (bundled) return bundled;
	if (cachedPreset) {
		var cachedFile = new File(cachedPreset);
		if (cachedFile.exists) return cachedFile.fsName;
	}
	return hcFindAudioPreset();
}

function hcWorkAreaType() {
	return (app.encoder && typeof app.encoder.ENCODE_ENTIRE !== "undefined") ? app.encoder.ENCODE_ENTIRE : 0;
}

function hcInOutWorkAreaType() {
	return (app.encoder && typeof app.encoder.ENCODE_IN_TO_OUT !== "undefined") ? app.encoder.ENCODE_IN_TO_OUT : 1;
}

/** Return the end of the visible sequence content. This is used only when
 * the editor has not set In/Out marks and deliberately asks to process the
 * complete timeline. */
function hcGetSequenceContentEndSecs(seq) {
	var endSecs = 0;
	try {
		var groups = [seq.videoTracks, seq.audioTracks];
		for (var g = 0; g < groups.length; g++) {
			var tracks = groups[g];
			for (var t = 0; tracks && t < tracks.numTracks; t++) {
				var clips = tracks[t].clips;
				for (var c = 0; clips && c < clips.numItems; c++) {
					var clip = clips[c];
					var clipEnd = clip && clip.end ? Number(clip.end.seconds) : 0;
					if (!isNaN(clipEnd) && clipEnd > endSecs) endSecs = clipEnd;
				}
			}
		}
	} catch (e) {}
	return endSecs;
}

/** Resolve the operation range from the editor's sequence In/Out marks.
 * If no valid marks exist, the caller can deliberately process the whole
 * sequence after showing a non-blocking warning in the panel. */
function hcGetTimelineRangeObject(seq) {
	try {
		if (!seq) return { ok: false, error: "אין רצף פעיל בטיימליין." };
		var inSecs = 0, outSecs = 0;
		try {
			inSecs = Number(seq.getInPoint());
			outSecs = Number(seq.getOutPoint());
		} catch (ignore) {}
		if (!isNaN(inSecs) && !isNaN(outSecs) && inSecs >= 0 && outSecs > inSecs) {
			return {
				ok: true, startSecs: inSecs, endSecs: outSecs, durationSecs: outSecs - inSecs,
				hasInOut: true, exportInOut: true, name: "טווח In/Out שנבחר"
			};
		}
		var sequenceEnd = hcGetSequenceContentEndSecs(seq);
		if (!(sequenceEnd > 0)) return { ok: false, error: "לא נמצא תוכן תקין ברצף הפעיל." };
		return {
			ok: true, startSecs: 0, endSecs: sequenceEnd, durationSecs: sequenceEnd,
			hasInOut: false, exportInOut: false, name: "כל הרצף הפעיל"
		};
	} catch (e) {
		return { ok: false, error: "לא ניתן לקרוא את טווח הטיימליין: " + e.toString() };
	}
}

function hcGetTimelineRange() {
	try {
		if (!app.project) return jsonErr("אין פרויקט פתוח");
		var seq = app.project.activeSequence;
		if (!seq) return jsonErr("אין רצף פעיל בטיימליין");
		var range = hcGetTimelineRangeObject(seq);
		return range.ok ? jsonOk(range) : jsonErr(range.error);
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/* Backward-compatible alias used by older panel code. It now intentionally
 * returns the sequence In/Out range instead of requiring a selected clip. */
function hcGetSelectedTimelineRange() {
	return hcGetTimelineRange();
}

/** Validate the immutable range captured by the panel at the start of a job.
 * Focus can change during export, so later stages must never re-read the
 * timeline's current marks or a clip selection. */
function hcResolveOperationRange(seq, capturedRangeStr) {
	if (capturedRangeStr !== undefined && capturedRangeStr !== null && capturedRangeStr !== "") {
		try {
			var captured = (typeof capturedRangeStr === "string") ? JSON.parse(capturedRangeStr) : capturedRangeStr;
			var start = Number(captured.startSecs);
			var end = Number(captured.endSecs);
			if (!isNaN(start) && !isNaN(end) && start >= 0 && end > start) {
				return {
					ok: true, startSecs: start, endSecs: end, durationSecs: end - start,
					hasInOut: !!captured.hasInOut, exportInOut: !!captured.exportInOut,
					isTrialCapped: !!captured.isTrialCapped,
					name: captured.name || "טווח הטיימליין"
				};
			}
		} catch (e) {}
		return { ok: false, error: "טווח הטיימליין שנשמר אינו תקין. סמנו מחדש In/Out או נסו לעבד את הרצף המלא." };
	}
	return hcGetTimelineRangeObject(seq);
}

function hcSetPendingCaptionRange(capturedRangeStr) {
	try {
		if (!app.project || !app.project.activeSequence) return jsonErr("אין רצף פעיל בטיימליין");
		var range = hcResolveOperationRange(app.project.activeSequence, capturedRangeStr);
		if (!range.ok) return jsonErr(range.error);
		HC_PENDING_CAPTION_RANGE = range;
		return jsonOk({ selection: range });
	} catch (e) {
		return jsonErr(e.toString());
	}
}

function hcSaveInOut(seq) {
	var saved = { hadInOut: false, inSecs: 0, outSecs: 0 };
	try {
		if (typeof seq.getInPointAsTime === "function") {
			var inTime = seq.getInPointAsTime();
			var outTime = seq.getOutPointAsTime();
			if (inTime && typeof inTime.seconds === "number" && inTime.seconds >= 0) saved.inSecs = inTime.seconds;
			if (outTime && typeof outTime.seconds === "number" && outTime.seconds > saved.inSecs) {
				saved.outSecs = outTime.seconds;
				saved.hadInOut = true;
			}
		}
	} catch (e) {}
	return saved;
}

function hcRestoreInOut(seq, saved) {
	try {
		if (saved.hadInOut) {
			seq.setInPoint(Math.round(saved.inSecs * 254016000000));
			seq.setOutPoint(Math.round(saved.outSecs * 254016000000));
		} else {
			seq.clearInPoint();
			seq.clearOutPoint();
		}
	} catch (e) {}
}

/** Apply the untouched automatic-cut engine only inside the selected timeline
 * item(s). The detector receives an exported selection whose timestamps start
 * at zero; this wrapper converts them back to sequence timestamps before the
 * engine is called. */
function hcApplySilenceCutsToSelection(payloadStr, capturedRangeStr) {
	var seq = null;
	var savedInOut = null;
	try {
		if (!app.project) return jsonErr("אין פרויקט פתוח");
		seq = app.project.activeSequence;
		if (!seq) return jsonErr("אין רצף פעיל בטיימליין");
		var range = hcResolveOperationRange(seq, capturedRangeStr);
		if (!range.ok) return jsonErr(range.error);
		var payload = JSON.parse(payloadStr);
		if (!payload || !payload.cuts || Object.prototype.toString.call(payload.cuts) !== "[object Array]") {
			return jsonErr("נתוני הקאטים אינם תקינים.");
		}
		for (var i = 0; i < payload.cuts.length; i++) {
			var cut = payload.cuts[i];
			if (!cut) continue;
			cut.start = Number(cut.start) + range.startSecs;
			cut.end = Number(cut.end) + range.startSecs;
		}
		var restrictedCuts = [];
		for (var j = 0; j < payload.cuts.length; j++) {
			var candidate = payload.cuts[j];
			if (!candidate || candidate.end <= range.startSecs || candidate.start >= range.endSecs) continue;
			restrictedCuts.push({
				start: Math.max(Number(candidate.start), range.startSecs),
				end: Math.min(Number(candidate.end), range.endSecs)
			});
		}
		payload.cuts = restrictedCuts;
		payload.workArea = "range";
		return hcApplySilenceCuts(JSON.stringify(payload));
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Attempt 1: Sequence.exportAsMediaDirect - Premiere's own "direct render"
 *  path. Fast and simple when it works, but documented (and confirmed in
 *  Adobe's community forums) to sometimes fail silently - no error, no
 *  output file - on some Premiere Pro 2025 installs. Returns immediately;
 *  js/main.js polls for the actual output file rather than trusting the
 *  return value alone. */
function hcExportDirect(outPath, cachedPreset, capturedRangeStr) {
	try {
		var seq = app.project.activeSequence;
		if (!seq) return jsonErr("אין רצף פעיל");

		var range = hcResolveOperationRange(seq, capturedRangeStr || HC_PENDING_CAPTION_RANGE);
		if (!range.ok) return jsonErr(range.error);
		var preset = hcResolvePreset(cachedPreset);
		if (!preset) {
			var detail = hcLastPresetSearchPaths.length
				? (" (חיפשתי תחת: " + hcLastPresetSearchPaths.join(" | ") + " | app.path: " + hcLastAppPath + ")")
				: "";
			return jsonErr("לא נמצאה הגדרת ייצוא אודיו (.epr) בהתקנת פרמייר" + detail);
		}

					var result;
			var needsInOut = !!range.exportInOut || !!range.isTrialCapped;
			try {
				if (needsInOut) {
					seq.setInPoint(Math.round(range.startSecs * 254016000000));
					seq.setOutPoint(Math.round(range.endSecs * 254016000000));
				}
				result = seq.exportAsMediaDirect(outPath, preset, needsInOut ? hcInOutWorkAreaType() : hcWorkAreaType());
			} finally {
				/* Do not leave export marks in the timeline: Premiere can then
				 * remain in an In/Out playback state until the editor clears them. */
				try { seq.clearInPoint(); } catch (ignoreIn) {}
				try { seq.clearOutPoint(); } catch (ignoreOut) {}
			}

		return jsonOk({ path: outPath, preset: preset, result: result, selection: range });
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Attempt 2 (fallback): queue the export as an Adobe Media Encoder job
 *  instead of rendering directly. This is the documented working
 *  alternative when exportAsMediaDirect is broken. Only queues the job
 *  and returns immediately - js/main.js polls for the output file. */
function hcExportViaEncoder(outPath, cachedPreset, capturedRangeStr) {
	try {
		var seq = app.project.activeSequence;
		if (!seq) return jsonErr("אין רצף פעיל");

		var range = hcResolveOperationRange(seq, capturedRangeStr || HC_PENDING_CAPTION_RANGE);
		if (!range.ok) return jsonErr(range.error);
		var preset = hcResolvePreset(cachedPreset);
		if (!preset) return jsonErr("לא נמצאה הגדרת ייצוא אודיו (.epr)");

		if (!app.encoder) {
			return jsonErr("app.encoder לא זמין - ודאו ש-Adobe Media Encoder מותקן (מותקן בדרך כלל יחד עם פרמייר דרך Creative Cloud)");
		}

					var jobId;
			var needsInOut = !!range.exportInOut || !!range.isTrialCapped;
			try {
				if (needsInOut) {
					seq.setInPoint(Math.round(range.startSecs * 254016000000));
					seq.setOutPoint(Math.round(range.endSecs * 254016000000));
				}
				jobId = app.encoder.encodeSequence(seq, outPath, preset, needsInOut ? hcInOutWorkAreaType() : hcWorkAreaType(), 1);
			} finally {
				try { seq.clearInPoint(); } catch (ignoreIn) {}
				try { seq.clearOutPoint(); } catch (ignoreOut) {}
			}

		if (!jobId) {
			return jsonErr("app.encoder.encodeSequence לא החזיר job (preset: " + preset + ")");
		}

		return jsonOk({ path: outPath, preset: preset, jobId: jobId, selection: range });
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Launches Adobe Media Encoder in the background if it isn't already
 *  running. Call this and give it a few seconds before hcExportViaEncoder,
 *  since queuing a job before AME has finished starting up can silently
 *  drop the job. */
function hcLaunchEncoder() {
	try {
		if (!app.encoder) return jsonErr("app.encoder לא זמין");
		app.encoder.launchEncoder();
		return jsonOk({});
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Recursively search bins under rootItem for the ProjectItem matching the
 *  SRT we just imported. Matches by filename (item.name), not by media
 *  path - getMediaPath() turned out to be unreliable for caption/subtitle
 *  items specifically (they aren't "media" in the traditional sense), so
 *  name matching against the Project panel entry is more robust. */
function hcFindProjectItemByName(rootItem, fileName, depth) {
	if (!rootItem || !rootItem.children || depth > 6) return null;
	for (var i = 0; i < rootItem.children.numItems; i++) {
		var item = rootItem.children[i];
		if (item.name === fileName) return item;
		if (item.children) {
			var found = hcFindProjectItemByName(item, fileName, depth + 1);
			if (found) return found;
		}
	}
	return null;
}

/** Picks whichever caption-format constant this Premiere version actually
 *  exposes, preferring subtitle/open-caption style (what a plain
 *  dialogue SRT should be) over broadcast CEA-608/708 formats. Adobe's
 *  scripting docs only show CAPTION_FORMAT_708 in their one example, so we
 *  don't hard-code a single name - we check what's really there. */
function hcCaptionFormatConstant() {
	var candidates = [
		"CAPTION_FORMAT_SUBTITLE",
		"CAPTION_FORMAT_SUBTITLES",
		"CAPTION_FORMAT_OPEN_CAPTIONS",
		"CAPTION_FORMAT_OPEN",
		"CAPTION_FORMAT_708",
		"CAPTION_FORMAT_608"
	];
	for (var i = 0; i < candidates.length; i++) {
		if (typeof Sequence[candidates[i]] !== "undefined") return { name: candidates[i], value: Sequence[candidates[i]] };
	}
	return null;
}

/** Import a generated SRT file into the project's Project panel, and try to
 *  also add it directly to the active sequence's timeline as a caption
 *  track (Sequence.createCaptionTrack) so it's ready to play immediately
 *  instead of needing a manual drag. This uses a documented but lightly-
 *  supported API, so if it doesn't work on this Premiere version, we don't
 *  fail the whole operation - we just report addedToTimeline: false (with
 *  a `debug` field explaining what step didn't work) and the caller falls
 *  back to telling the user to drag it manually, exactly like before. */
function hcImportSrt(srtPath) {
	try {
		var ok = app.project.importFiles([srtPath], true, app.project.rootItem, false);
		if (!ok) return jsonErr("הייבוא נכשל - ודאו שהקובץ תקין ולא פתוח בתוכנה אחרת");

		var addedToTimeline = false;
		var debug = "";
		var seq = app.project.activeSequence;

		if (!seq) {
			debug = "no active sequence";
		} else {
			var fileName = new File(srtPath).name; // e.g. "seq_1785800466880.srt"
			var item = hcFindProjectItemByName(app.project.rootItem, fileName, 0);
			if (!item) {
				debug = "project item not found by name (" + fileName + ")";
			} else {
				var fmt = hcCaptionFormatConstant();
				var captionStartSecs = 0;
				try {
					if (HC_PENDING_CAPTION_RANGE && typeof HC_PENDING_CAPTION_RANGE.startSecs === "number") {
						captionStartSecs = HC_PENDING_CAPTION_RANGE.startSecs;
					}
					var result = fmt
						? seq.createCaptionTrack(item, captionStartSecs, fmt.value)
						: seq.createCaptionTrack(item, captionStartSecs);
					addedToTimeline = (result === true);
					debug = "createCaptionTrack(" + (fmt ? fmt.name : "no format arg") + ", start=" + captionStartSecs + ") returned " + String(result);
				} catch (e) {
					debug = "createCaptionTrack threw: " + e.toString();
				}
			}
		}

		HC_PENDING_CAPTION_RANGE = null;
		return jsonOk({ addedToTimeline: addedToTimeline, debug: debug });
	} catch (e) {
		HC_PENDING_CAPTION_RANGE = null;
		return jsonErr(e.toString());
	}
}

// =====================================================================
// After Effects support. Everything below only runs when this same jsx
// file happens to be loaded inside After Effects instead of Premiere -
// AE has a completely different scripting model (compositions/layers,
// no sequences/tracks, no built-in caption tracks, a render-queue-based
// export instead of exportAsMediaDirect/Media Encoder), so none of the
// Premiere functions above apply here at all.
// =====================================================================

/** Info about the active composition, or an error if none is open/active. */
function hcAEGetCompInfo() {
	try {
		var comp = app.project.activeItem;
		if (!comp || !(comp instanceof CompItem)) {
			return jsonErr("אין קומפוזיציה פעילה - פתחו/בחרו קומפוזיציה בפרויקט");
		}
		return jsonOk({ name: comp.name, duration: comp.duration });
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Render the active comp's audio to outPath via the Render Queue.
 *  AE has no one-line "export audio" call - it needs an Output Module
 *  Template that's already configured for audio-only output (WAV), the
 *  same kind of one-time manual setup we ended up needing for Premiere's
 *  .epr preset. If templateName is given, that exact template is used (and
 *  the call fails clearly if it doesn't exist); otherwise a few common
 *  self-explanatory names are tried automatically.
 *  Uses the undocumented renderQueue.renderAsync() when available so it
 *  doesn't block the whole AE UI for the render duration; falls back to
 *  the documented (blocking) render() otherwise. */
function hcAEExportAudio(outPath, templateName) {
	var rqItem = null;
	try {
		var comp = app.project.activeItem;
		if (!comp || !(comp instanceof CompItem)) return jsonErr("אין קומפוזיציה פעילה");

		rqItem = app.project.renderQueue.items.add(comp);
		var om = rqItem.outputModule(1);

		var tried = [];
		var applied = null;

		if (templateName) {
			tried.push(templateName);
			try { om.applyTemplate(templateName); applied = templateName; } catch (e) { /* fall through to error below */ }
		} else {
			// "AIFF 48kHz" ships as a built-in AE template on most installs -
			// try it first before anything WAV-named, since AE calls its
			// audio-only format "AIFF" (Premiere's "Waveform Audio" naming
			// doesn't exist here at all).
			var candidates = ["AIFF 48kHz", "TopCaptions Audio", "WAV Audio", "WAV", "Audio Only (WAV)"];
			for (var i = 0; i < candidates.length; i++) {
				tried.push(candidates[i]);
				try { om.applyTemplate(candidates[i]); applied = candidates[i]; break; } catch (e) { /* try next */ }
			}
		}

		if (!applied) {
			rqItem.remove();
			return jsonErr(
				"לא נמצאה תבנית פלט אודיו (נוסה: " + tried.join(", ") + "). " +
				"צרו תבנית חדשה פעם אחת: Edit → Templates → Output Module... → Format: WAV → " +
				"שמרו עם שם, ורשמו אותו בהגדרות המתקדמות של הפאנל."
			);
		}

		om.file = new File(outPath);
		rqItem.render = true; // explicit, rather than assuming the default

		// Force the FULL composition duration regardless of any work-area
		// trim the user may have set (extremely common while previewing in
		// AE) - without this, a trimmed work area silently renders only
		// that shorter range with no error, producing a valid-looking but
		// wrong/partial audio file that then fails in confusing ways later.
		try {
			rqItem.timeSpanStart = 0;
			rqItem.timeSpanDuration = comp.duration;
		} catch (e) { /* non-fatal - some AE versions may not expose these; falls back to comp's own work area */ }

		// app.project.renderQueue.render() is AE's one documented, reliable
		// way to actually run a queued job - it blocks until finished
		// (AE's UI may look busy for the duration), but that's preferable
		// to guessing at an unverified async alternative that turned out
		// to not reliably produce output.
		app.project.renderQueue.render();

		var status = String(rqItem.status);
		// status 3019 = RQItemStatus.DONE (confirmed render success) - but
		// that doesn't guarantee the file landed exactly at outPath: some
		// output module templates normalize/resolve the final filename
		// themselves. Trust the output module's own reported path over our
		// original guess if they differ and only the former actually has a
		// real file - that's the file AE really wrote.
		var outFile = new File(outPath);
		var actualPath = outPath;

		if (!outFile.exists || outFile.length <= 1000) {
			try {
				var omFile = om.file; // re-read after render, in case AE resolved it differently
				if (omFile && omFile.fsName !== outPath) {
					var omActual = new File(omFile.fsName);
					if (omActual.exists && omActual.length > 1000) {
						outFile = omActual;
						actualPath = omFile.fsName;
					}
				}
			} catch (e) { /* fall through to the failure branch below */ }
		}

		if (!outFile.exists || outFile.length <= 1000) {
			var omPathForDebug = "";
			try { omPathForDebug = om.file ? om.file.fsName : "(none)"; } catch (e) { omPathForDebug = "(unreadable)"; }
			try { rqItem.remove(); } catch (e) { /* non-fatal cleanup */ }
			return jsonErr(
				"הרינדור הסתיים בהצלחה (סטטוס: " + status + ") אך לא נמצא קובץ אודיו תקין. " +
				"נתיב מבוקש: " + outPath + " | נתיב בפועל לפי ה-Output Module: " + omPathForDebug + ". " +
				"ודאו שהתבנית '" + applied + "' באמת מוגדרת ל-Format: WAV עם Audio Output מופעל " +
				"(Edit → Templates → Output Module...)."
			);
		}

		try { rqItem.remove(); } catch (e) { /* non-fatal cleanup - job already rendered */ }

		return jsonOk({ path: actualPath, template: applied, status: status });
	} catch (e) {
		try { if (rqItem) rqItem.remove(); } catch (e2) { /* non-fatal cleanup */ }
		return jsonErr(e.toString());
	}
}

/** AE has no native caption/subtitle track, so instead of importing an
 *  SRT, this creates one text layer per cue directly in the active comp,
 *  each visible only for its own start/end range (via inPoint/outPoint) -
 *  the closest AE equivalent to a caption track. cuesJson is an array of
 *  {start, end, text} objects (seconds), written by caption_engine.py
 *  alongside the .srt file. */
function hcAEAddCaptionLayers(cuesJson) {
	try {
		var comp = app.project.activeItem;
		if (!comp || !(comp instanceof CompItem)) return jsonErr("אין קומפוזיציה פעילה");

		var cues = JSON.parse(cuesJson);
		var count = 0;
		for (var i = 0; i < cues.length; i++) {
			var c = cues[i];
			if (!c.text) continue;
			var layer = comp.layers.addText(c.text);
			layer.name = "Caption " + (i + 1);
			layer.inPoint = c.start;
			layer.outPoint = c.end;
			try {
				var pos = layer.property("Transform").property("Position");
				pos.setValue([comp.width / 2, comp.height * 0.88]);
			} catch (e) { /* non-fatal styling detail */ }
			count++;
		}
		return jsonOk({ count: count });
	} catch (e) {
		return jsonErr(e.toString());
	}
}

/** Jumps straight to AE's "Output Module Templates" dialog, so a first-time
 *  friend doesn't have to hunt through Edit > Templates > Output Module...
 *  themselves - just click a button in the panel. Uses AE's undocumented
 *  (but long-standing, community-relied-upon) Menu Command ID mechanism,
 *  since there's no official scripting API to open this dialog directly. */
function hcAEOpenOutputModuleTemplates() {
	try {
		var cmdId = app.findMenuCommandId("Output Module...");
		if (!cmdId) return jsonErr("לא נמצאה פקודת התפריט (ייתכן שהשם שונה בגרסת AE הזו) - פתחו ידנית: Edit → Templates → Output Module...");
		app.executeCommand(cmdId);
		return jsonOk({});
	} catch (e) {
		return jsonErr(e.toString());
	}
}
