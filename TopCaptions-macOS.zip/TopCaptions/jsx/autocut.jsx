// autocut.jsx - TopCaptions automatic silence-cut engine for Premiere Pro.
// Receives detected non-speech ranges from the panel and removes them as one
// undoable operation. The algorithm ports the proven two-phase razor +
// reverse-track deletion approach from the supplied REDitors project.

var TopCaptions = (typeof TopCaptions !== "undefined") ? TopCaptions : {};
TopCaptions.AutoCut = TopCaptions.AutoCut || {};

(function (AC) {
    var TICKS_PER_SEC = 254016000000;

    function ok(data) {
        try { return JSON.stringify(data); }
        catch (e) { return '{"ok":false,"error":"JSON serialization failed"}'; }
    }

    function err(message) {
        return '{"ok":false,"error":' + JSON.stringify(String(message)) + '}';
    }

    function parsePayload(value) {
        try { return JSON.parse(value); }
        catch (e) { return null; }
    }

    function isArray(value) {
        return Object.prototype.toString.call(value) === "[object Array]";
    }

    function activeSequence() {
        try {
            if (typeof app === "undefined" || !app.project) return null;
            return app.project.activeSequence || null;
        } catch (e) {
            return null;
        }
    }

    function isTrackLocked(track) {
        try {
            return (typeof track.isLocked === "function") ? !!track.isLocked() : !!track.isLocked;
        } catch (e) {
            return false;
        }
    }

    function secondsPerFrame(sequence) {
        var value = 1 / 25;
        try {
            var frameRate = sequence.getSettings().videoFrameRate;
            var ticks = frameRate && frameRate.ticks ? parseFloat(frameRate.ticks) : 0;
            if (ticks > 0) value = ticks / TICKS_PER_SEC;
        } catch (e) {}
        return value;
    }

    // payload: {cuts:[{start:Number,end:Number}], videoTracks:Boolean,
    //           cutMethod:"batch"|"single_pass", workArea:"entire"|"in_to_out"}
    AC.applySilenceCuts = function (payloadStr) {
        var undoOpen = false;
        try {
            var payload = parsePayload(payloadStr);
            if (!payload) return err("Invalid automatic-cut payload.");
            if (!isArray(payload.cuts)) return err("The automatic-cut payload must contain a cuts array.");

            var sequence = activeSequence();
            if (!sequence) return err("No active sequence. Open a sequence before running automatic cuts.");

            var spf = secondsPerFrame(sequence);
            var audioCount = 0;
            var videoCount = 0;
            try { audioCount = sequence.audioTracks.numTracks; } catch (e) {}
            try { videoCount = sequence.videoTracks.numTracks; } catch (e) {}

            // The panel wrapper already clips the supplied cut list to the
            // requested timeline range. Never set, clear or restore Premiere
            // In/Out marks here: leaving those marks active can block normal
            // playback until the editor manually runs Clear In and Out.

            var cuts = [];
            for (var i = 0; i < payload.cuts.length; i++) {
                var candidate = payload.cuts[i];
                if (!candidate) continue;
                var start = parseFloat(candidate.start);
                var end = parseFloat(candidate.end);
                if (isNaN(start) || isNaN(end) || end <= start) continue;
                var frameIn = Math.round(start / spf);
                var frameOut = Math.round(end / spf);
                if (frameOut > frameIn) cuts.push({ cutIn: frameIn, cutOut: frameOut });
            }
            if (cuts.length === 0) {
                return ok({ ok: true, appliedCuts: 0, appliedClips: 0 });
            }
            cuts.sort(function (a, b) { return a.cutIn - b.cutIn; });

            var savedDisplayFormat = 109;
            try {
                var settings = sequence.getSettings();
                savedDisplayFormat = settings.videoDisplayFormat;
                if (settings.videoDisplayFormat !== 109) {
                    settings.videoDisplayFormat = 109;
                    sequence.setSettings(settings);
                }
            } catch (e) {}

            try { app.enableQE(); } catch (e) {}
            var qeSequence = null;
            try { qeSequence = qe.project.getActiveSequence(); } catch (e) {}
            if (!qeSequence) {
                try {
                    var unavailableSettings = sequence.getSettings();
                    unavailableSettings.videoDisplayFormat = savedDisplayFormat;
                    sequence.setSettings(unavailableSettings);
                } catch (restoreError) {}
                return err("Premiere's timeline cutting interface is not available. Restart Premiere and try again.");
            }

            var removeVideo = (payload.videoTracks !== false);
            var tolerance = 0.005;
            var appliedClips = 0;
            var removedFrames = 0;

            try { app.project.beginUndoGroup("TopCaptions Automatic Cuts"); undoOpen = true; } catch (e) {}

            if (payload.cutMethod === "single_pass") {
                // More conservative alternative for short timelines: each zone is
                // completed from end to start before the next one begins.
                cuts.sort(function (a, b) { return b.cutIn - a.cutIn; });
                for (var singleIndex = 0; singleIndex < cuts.length; singleIndex++) {
                    var singleCut = cuts[singleIndex];
                    try { qeSequence.razor(String(singleCut.cutIn)); } catch (e) {}
                    try { qeSequence.razor(String(singleCut.cutOut)); } catch (e) {}
                    var singleStart = singleCut.cutIn * spf;
                    var singleEnd = singleCut.cutOut * spf;

                    function removeSingleTrack(track) {
                        if (isTrackLocked(track)) return;
                        try {
                            for (var clipIndex = track.clips.numItems - 1; clipIndex >= 0; clipIndex--) {
                                var clipStart = track.clips[clipIndex].start.seconds;
                                if (clipStart >= singleStart - tolerance && clipStart < singleEnd - tolerance) {
                                    try { track.clips[clipIndex].remove(true, false); } catch (removeError) {}
                                    appliedClips++;
                                }
                            }
                        } catch (trackError) {}
                    }

                    for (var audioIndex = 0; audioIndex < audioCount; audioIndex++) removeSingleTrack(sequence.audioTracks[audioIndex]);
                    if (removeVideo) {
                        for (var videoIndex = 0; videoIndex < videoCount; videoIndex++) removeSingleTrack(sequence.videoTracks[videoIndex]);
                    }
                    removedFrames += singleCut.cutOut - singleCut.cutIn;
                }
            } else {
                // Two-phase batch algorithm:
                // 1) razor every unique boundary once;
                // 2) make a single reverse pass through each unlocked track.
                var pointMap = {};
                for (var pointIndex = 0; pointIndex < cuts.length; pointIndex++) {
                    pointMap[cuts[pointIndex].cutIn] = true;
                    pointMap[cuts[pointIndex].cutOut] = true;
                }
                var razorPoints = [];
                for (var point in pointMap) razorPoints.push(parseInt(point, 10));
                razorPoints.sort(function (a, b) { return a - b; });
                for (var razorIndex = 0; razorIndex < razorPoints.length; razorIndex++) {
                    try { qeSequence.razor(String(razorPoints[razorIndex])); } catch (e) {}
                }

                var zones = [];
                for (var zoneIndex = 0; zoneIndex < cuts.length; zoneIndex++) {
                    zones.push({
                        inSec: cuts[zoneIndex].cutIn * spf,
                        outSec: cuts[zoneIndex].cutOut * spf,
                        durationFrames: cuts[zoneIndex].cutOut - cuts[zoneIndex].cutIn,
                        counted: false
                    });
                }

                function findZone(clipStart) {
                    var low = 0;
                    var high = zones.length - 1;
                    while (low <= high) {
                        var middle = (low + high) >> 1;
                        var zone = zones[middle];
                        if (clipStart >= zone.inSec - tolerance && clipStart < zone.outSec - tolerance) return middle;
                        if (clipStart < zone.inSec - tolerance) high = middle - 1;
                        else low = middle + 1;
                    }
                    return -1;
                }

                function removeFromTrack(track) {
                    if (isTrackLocked(track)) return;
                    try {
                        for (var index = track.clips.numItems - 1; index >= 0; index--) {
                            var clipStart = track.clips[index].start.seconds;
                            var matchedZone = findZone(clipStart);
                            if (matchedZone >= 0) {
                                try { track.clips[index].remove(true, false); } catch (removeError) {}
                                appliedClips++;
                                if (!zones[matchedZone].counted) {
                                    zones[matchedZone].counted = true;
                                    removedFrames += zones[matchedZone].durationFrames;
                                }
                            }
                        }
                    } catch (trackError) {}
                }

                for (var audioTrack = 0; audioTrack < audioCount; audioTrack++) removeFromTrack(sequence.audioTracks[audioTrack]);
                if (removeVideo) {
                    for (var videoTrack = 0; videoTrack < videoCount; videoTrack++) removeFromTrack(sequence.videoTracks[videoTrack]);
                }
            }

            if (undoOpen) {
                try { app.project.endUndoGroup(); } catch (e) {}
                undoOpen = false;
            }

            try {
                var finalSettings = sequence.getSettings();
                finalSettings.videoDisplayFormat = savedDisplayFormat;
                sequence.setSettings(finalSettings);
            } catch (e) {}

            return ok({
                ok: true,
                appliedCuts: cuts.length,
                appliedClips: appliedClips,
                secondsRemoved: parseFloat((removedFrames * spf).toFixed(3))
            });
        } catch (e) {
            if (undoOpen) {
                try { app.project.endUndoGroup(); } catch (endError) {}
            }
            return err(e && e.message ? e.message : e);
        }
    };
})(TopCaptions.AutoCut);

function hcApplySilenceCuts(payloadStr) {
    return TopCaptions.AutoCut.applySilenceCuts(payloadStr);
}

try { $.writeln("[TopCaptions] autocut.jsx loaded"); } catch (e) {}
