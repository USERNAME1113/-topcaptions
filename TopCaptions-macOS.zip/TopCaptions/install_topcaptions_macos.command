#!/bin/bash
# TopCaptions macOS installer
# Run by double-clicking after extracting the distribution ZIP, or from Terminal.
# The extension, its bundled EPR preset, and its local Python environment are
# installed only inside the current user's Library folder.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SUPPORT="$HOME/Library/Application Support"
EXT_DEST="$APP_SUPPORT/Adobe/CEP/extensions/TopCaptions"
BASE="$APP_SUPPORT/HebrewCaptions"
VENV="$BASE/venv"
LOGFILE="$HOME/Library/Logs/TopCaptions-install.log"
PYTHON=""

mkdir -p "$(dirname "$LOGFILE")"
exec > >(tee "$LOGFILE") 2>&1

echo "==============================================================="
echo "TopCaptions for macOS — installation"
echo "==============================================================="

find_python() {
  local candidate version
  for candidate in \
    "/Library/Frameworks/Python.framework/Versions/3.12/bin/python3" \
    "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3" \
    "/Library/Frameworks/Python.framework/Versions/3.10/bin/python3" \
    "$(command -v python3 2>/dev/null || true)"; do
    [ -n "$candidate" ] || continue
    [ -x "$candidate" ] || continue
    version="$($candidate -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || true)"
    case "$version" in
      3.9|3.10|3.11|3.12|3.13|3.14) PYTHON="$candidate"; return 0 ;;
    esac
  done
  return 1
}

if ! find_python; then
  echo
  echo "Python 3.9 or newer is required for the local transcription engine."
  echo "Open the official, signed Python installer, finish its standard installation,"
  echo "then run this TopCaptions installer again."
  echo "https://www.python.org/downloads/macos/"
  open "https://www.python.org/downloads/macos/" || true
  exit 1
fi

echo "Using Python: $PYTHON"
mkdir -p "$APP_SUPPORT/Adobe/CEP/extensions" "$BASE"

# Replace the extension atomically enough for ordinary user installs. Do not
# copy development/build output into the installed CEP directory.
rm -rf "$EXT_DEST"
mkdir -p "$EXT_DEST"
rsync -a \
  --exclude=".DS_Store" \
  --exclude="Output" \
  --exclude="*.iss" \
  --exclude="setup_windows.bat" \
  --exclude="setup_windows_auto.bat" \
  --exclude="TopCaptions-Setup.exe" \
  --exclude="install_topcaptions_macos.command" \
  "$SCRIPT_DIR/" "$EXT_DEST/"

"$PYTHON" -m venv "$VENV"
"$VENV/bin/python" -m pip install --upgrade pip
"$VENV/bin/python" -m pip install -r "$EXT_DEST/backend/requirements.txt"

# CEP extensions installed outside Adobe Exchange need this user-level setting.
for version in 9 10 11 12; do
  defaults write "com.adobe.CSXS.$version" PlayerDebugMode 1
 done

echo
echo "==============================================================="
echo "Installation complete."
echo "1. Close Premiere Pro / After Effects completely if either is open."
echo "2. Open it again, then choose Window > Extensions > TopCaptions."
echo "3. The first transcription downloads the language model once."
echo "Installation log: $LOGFILE"
echo "==============================================================="

osascript -e 'display notification "TopCaptions installation completed" with title "TopCaptions"' || true
