# TopCaptions - Premiere Pro & After Effects panel (MVP)

> **Note on paths below:** the plugin is branded **TopCaptions** (what you
> see in Premiere/AE menus), but its internal data folder on disk is still
> named `HebrewCaptions` under the hood - kept that way on purpose so
> anyone who already ran the Python setup or picked an export preset
> doesn't lose that configuration. Don't rename that folder yourself.

> See `LICENSE.txt` for copyright terms.

A CEP extension for Windows that transcribes the active Premiere Pro
sequence or After Effects composition to Hebrew, using the free,
open-source **ivrit-ai** Whisper models (Apache-2.0) via `faster-whisper`.

No account, no server, no subscription - everything runs locally on your
machine.

## Quick install (for yourself or a friend)

1. **Requirements:** Windows 10/11, Premiere Pro 2024+ or After Effects
   2023+, and [Python 3.10+](https://www.python.org/downloads/) - during
   install, check **"Add python.exe to PATH"**.
2. Unzip this package anywhere.
3. **Double-click `setup_windows.bat`.** This one script does everything:
   - creates a dedicated Python environment and installs `faster-whisper`
   - copies the extension into Premiere/AE's extensions folder
   - flips the one registry setting Adobe requires for unsigned
     (non-Store) extensions
4. Restart Premiere Pro / After Effects.
5. Open **Window > Extensions > TopCaptions**. The Python path field is
   already correct - nothing to type or paste.
6. Click "צור כתוביות". **The first run needs internet** - it downloads
   the AI model (~1.6GB) once; every run after that is fast and fully
   offline.

That's the whole setup. Everything below is background/reference detail,
not additional steps.

### Sending this to friends

Just send them this same folder/zip and point them at step 3 above - the
script handles the rest. The one thing that can't be automated or bundled
in advance is the ~1.6GB model download in step 6, since it needs their
own internet connection the first time (this isn't a limitation specific
to this project - even paid commercial tools in this space, like Subli,
download their model on first run rather than bundling it in the
installer, since baking a multi-GB file into every copy of the installer
isn't practical to distribute).

### Alternative: installing as a `.zxp`

If you'd rather not use the unpacked/debug-mode method above (step 3's
registry change), `TopCaptions.zxp` is the same extension packaged in
the standard CEP installer format. Install it with the free, widely-used
**[ZXP Installer](https://zxpinstaller.com/)** tool (drag the `.zxp`
file onto it) - no registry edit needed. You'll still need to separately
run `setup_windows.bat` (or at least its Python-setup part) once for the
transcription backend, since the `.zxp` itself only contains the
extension code, not Python or the AI model.

### Building a true single-click `.exe` installer (recommended for wide distribution)

If unzipping a folder and double-clicking a `.bat` file feels like too
many steps to ask of friends, `TopCaptions.iss` in this package is a
ready-to-go **[Inno Setup](https://jrsoftware.org/isdl.php)** script (free,
the standard tool indie developers use for exactly this). It bundles
every file here into one `TopCaptions-Setup.exe` that, when double-clicked,
extracts everything AND automatically runs `setup_windows.bat` for the
user - genuinely one click, no manual folder-copying, no registry editing
on their end at all.

This can't be built from a non-Windows environment, so you'll need to do
this part yourself, once, on a Windows machine (not repeated per friend -
just once per version you release):

1. Install Inno Setup (free, ~2 minutes): https://jrsoftware.org/isdl.php
2. Make sure `TopCaptions.iss` sits in the same folder as `CSXS/`,
   `backend/`, `css/`, `js/`, `jsx/`, `index.html`, `LICENSE.txt`,
   `README.md`, and `setup_windows.bat` (exactly how this package is laid
   out already).
3. Right-click `TopCaptions.iss` → **Compile** (or open it in Inno Setup
   and press F9).
4. Inno Setup produces `Output\TopCaptions-Setup.exe`. That single file is
   now everything a friend needs - send them just that.

## Requirements (detail)

- Windows 10/11
- Adobe Premiere Pro 2024+, or After Effects 2023+ (CEP 11 host)
- Python 3.10+, on PATH
- ~3 GB free disk space for the model, and a decent GPU is a speed boost
  (CPU works too, just slower - see "CPU only, deliberately" below)

## Install the Python backend (what `setup_windows.bat` does)

If Python 3.10+ isn't already on the machine, the script downloads and
silently installs a pinned, known-good version (currently 3.12.7) from
python.org itself first - no manual download needed, no popups, no admin
rights required (it's a per-user install). It then creates a virtual
environment at `%APPDATA%\HebrewCaptions\venv` and installs
`faster-whisper` into it, copies the extension itself into Premiere/AE's
extensions folder, and enables the CSXS debug-mode registry key for
versions 9 through 12.

If the automatic Python install can't complete for some reason (e.g. no
internet, or something blocking the download), the script falls back to
the previous manual instructions instead of just failing.

The Hebrew model itself is **not** downloaded by this script - it
downloads automatically, the first time you click "Transcribe", into
whatever folder you set as "Model directory" in the panel (default:
`%APPDATA%\HebrewCaptions\models`). That first run will take a while
(it's pulling ~1.6 GB from Hugging Face); after that it's cached locally.

## Install the panel manually (only if the script's step 3 didn't work)

1. Enable debug mode so Premiere/AE loads unsigned extensions. Open
   PowerShell and run (repeat for each CSXS version if unsure which
   applies):
   ```
   New-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.11" -Name PlayerDebugMode -Value 1 -PropertyType String -Force
   ```
2. Copy this whole folder (the one containing `CSXS`, `index.html`, etc.) into:
   ```
   C:\Users\<you>\AppData\Roaming\Adobe\CEP\extensions\TopCaptions
   ```
   (create the `extensions` folder if it doesn't exist)
3. Restart Premiere Pro / After Effects.
4. Open the panel from **Window > Extensions > TopCaptions** - same
   menu path in both Premiere Pro and After Effects, since the same
   extensions folder is shared by all Adobe apps using this CSXS version.

## 4. First run in the panel

If you used `setup_windows.bat`, steps 1-3 below are already done for you
- the Python path field is pre-filled correctly. Otherwise:

1. In the panel, set **Python path** to:
   ```
   %APPDATA%\HebrewCaptions\venv\Scripts\python.exe
   ```
   (expand `%APPDATA%` to your actual path, e.g. `C:\Users\Dana\AppData\...`)
2. Leave **Model directory** as the default, or point it somewhere with more
   free space.
3. Click **עדכן הגדרות** (Update settings).

Then, either way:

4. Open a sequence (Premiere) or composition (After Effects), then click
   **צור כתוביות** (Generate captions).
5. First run: the model downloads (progress shown in the log), then
   transcription starts. Once done, captions are added automatically -
   to the timeline in Premiere, or as text layers in After Effects.

### Reusing a model you already downloaded via Subli

Before downloading anything, the panel checks two places for the model,
in order:

1. Its own model folder (`%APPDATA%\HebrewCaptions\models` by default)
2. `%LOCALAPPDATA%\Subli\models` - if you've run Subli before, the exact
   same `ivrit-turbo` model is already sitting there

If it finds the model under Subli's folder, it copies it over once (a
local file copy, no network) and never downloads it. This only works if
Subli has already downloaded the model at least once on this machine -
there's no way for the plugin (or anyone) to conjure the model files out
of the Subli `.zxp` installer itself, since that installer doesn't bundle
the weights either - it downloads them the same way, on first run.

### If "audio export preset not found" shows up

The very first export on a given machine searches the whole Adobe install
folder for a WAV export preset (this can take a few seconds). **On some
newer Premiere Pro versions (2025+), Adobe no longer ships that preset
file at all**, so the search will legitimately find nothing - that's not
a bug to keep chasing, it's a missing file.

The fix: create your own preset once, and point the panel at it.

1. In Premiere: **File → Export → Media**.
2. Set the format to **Waveform Audio**.
3. Click **Save Preset**, give it any name, save it anywhere (e.g. your
   Desktop).
4. Close the export dialog without exporting (Cancel is fine).
5. Back in the panel, click **בחר קובץ .epr ידנית** next to "קובץ הגדרות
   ייצוא אודיו" and select the `.epr` file you just saved.

### If the audio export never produces a file

Earlier versions of this plugin used `Sequence.exportAsMediaDirect`
("direct render," no separate app involved), which turned out to be
unreliable on some Premiere Pro 2025 installs - it can return without
error yet never actually write anything, independent of the preset or
parameters used (this is a reported Adobe bug, not specific to this
plugin).

The plugin now:

1. Searches your Premiere install for a compatible `.epr` preset
   automatically (and caches the result once found). Your own manually-
   picked preset, if you set one, is always tried first. Nothing
   third-party is bundled in this build - see the note below.
2. Tries the fast direct-render path first, but only waits ~15 seconds
   for it to actually start producing a file.
3. If nothing appears in that window, automatically falls back to
   queuing the export through **Adobe Media Encoder** instead
   (`app.encoder.encodeSequence`) - the documented working alternative -
   giving it up to 90 seconds to start (it may need to launch first) and
   several minutes to finish on longer sequences.

**Note on `presets/audio.epr`:** an earlier build of this project shipped
a `.epr` file here, copied from a different app's install as a shortcut.
That file's real origin wasn't this project's own work, so it's no longer
included - the search + manual-selection flow above is now the only way a
preset gets picked, which is slower to first-configure but fully
independent.

This means Adobe Media Encoder should ideally be installed (it normally
comes bundled with Premiere Pro via Creative Cloud), as a safety net for
step 3, even though step 1/2 will often succeed without needing it.

## How it works (for reference)

- `jsx/main.jsx` - runs inside Premiere (ExtendScript). Exports the active
  sequence's audio to a WAV using a bundled system preset, and imports the
  finished SRT back into the project.
- `js/main.js` - the panel's UI logic. Spawns the Python worker as a child
  process and streams its JSON progress events into the log/progress bar.
- `backend/caption_engine.py` - loads `ivrit-ai/whisper-large-v3-turbo-ct2`
  via `faster-whisper` and writes a plain SRT (one cue per Whisper segment).

## Swapping in the more accurate model

The worker also knows `ivrit-large` (`ivrit-ai/whisper-large-v3-ct2` - slower,
more accurate). To use it, change `"--model", "ivrit-turbo"` to
`"--model", "ivrit-large"` in `js/main.js` (`runTranscription`). A model
picker in the UI is an easy next step if you want it later.

## Cue splitting: smart split vs. fixed word count

By default ("פיצול חכם לפי משפטים", on by default), cues are grouped by
sentence boundary instead of a fixed word count. This matters
specifically for Hebrew: splitting mid-sentence at a fixed word count can
glue the tail of one sentence onto the start of an unrelated next one
(e.g. "...sales commissions. area Beit Shemesh..." as a single cue),
which reads as broken Hebrew regardless of word count. Smart split never
crosses a sentence-ending punctuation mark (`. ? ! : ; ׃ …`) when forming
a cue, so a cue is always a real Hebrew unit even if that means it's
longer or shorter than any fixed target.

Turning "פיצול חכם" off exposes the older fixed-word-count control
(`--words-per-line N`) instead, with no sentence awareness - useful if
you specifically want uniform-length cues and don't mind occasional
mid-sentence breaks.

## CPU only, deliberately

Transcription always runs on CPU, even though `faster-whisper` supports
GPU acceleration. On Windows, attempting CUDA without a matching install
(the right NVIDIA CUDA/cuBLAS DLLs) doesn't raise a normal Python
exception you can catch and fall back from - it hard-crashes the whole
process. CPU is reliable everywhere and fast enough for this model size,
so it's not worth chasing GPU support until there's a safe way to detect
a working CUDA setup before attempting to use it.

## Known limitations of this MVP

- Windows only (uses `python.exe`, Windows paths, and looks for Premiere
  under `Program Files`).
- No word-level cue splitting - each subtitle is a full Whisper segment,
  which can run a bit long on screen. Subli's word-limited grouping is a
  reasonable next feature to add if you want tighter captions.
- No RTL punctuation cleanup beyond a basic embedding fix, no emoji, no
  auto-cut/keyword detection - by design, per your MVP scope.

## After Effects support

The same panel also runs inside After Effects (it shares almost all of
the same code - only the pieces that touch host-specific APIs are
different). A few things work differently there:

- **Audio export needs a one-time Output Module Template.** AE has no
  built-in "export just the audio" option scriptable in one line, unlike
  Premiere. Once, per machine: **Edit → Templates → Output Module...** →
  set **Format: AIFF** (After Effects doesn't have a "Waveform Audio"
  option like Premiere does - AIFF is its equivalent) → save it with a
  name → paste that name into
  "שם תבנית פלט אודיו (After Effects)" in the panel's advanced settings.
  Without this, export will fail with a clear error telling you to do
  this.
- **Captions become text layers, not a caption track** - AE has no
  built-in caption/subtitle track at all, so instead of importing an SRT,
  the panel creates one text layer per cue directly in the composition,
  each visible only during its own time range (`inPoint`/`outPoint`).
  Positioned near the bottom-center by default; restyle/reposition as you
  like afterward, same as any other text layer.
- Rendering uses the undocumented `renderQueue.renderAsync()` when
  available (non-blocking), falling back to the documented `render()`
  (which blocks AE's UI for the render's duration) if not.
