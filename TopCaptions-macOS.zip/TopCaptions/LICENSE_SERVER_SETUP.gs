/**
 * TopCaptions license + trial-usage server - Google Apps Script
 * ================================================================
 * This is the ONLY place that actually remembers anything long-term -
 * which keys are claimed, by which device, and how many trial seconds
 * each device has used. The plugin itself has no memory of its own: every
 * install calls this script, and this script is the single shared source
 * of truth. That's true even if someone deletes every local file the
 * plugin creates and reinstalls from scratch - the device ID this script
 * tracks doesn't come from any file the plugin controls (it's Windows'
 * own per-installation machine ID), so there's nothing local to delete
 * that would reset it.
 *
 * SETUP (about 10 minutes, no coding needed beyond pasting this file):
 *
 * 1. Go to https://sheets.google.com and create a new blank spreadsheet
 *    (or reuse the one you already made for the earlier version of this).
 *
 * 2. Create TWO sheet tabs (bottom-left of the screen):
 *
 *    Tab 1, named exactly: Keys
 *      Row 1 headers: A1=Key   B1=Used   C1=UsedAt   D1=DeviceId
 *      Starting at A2, paste all 200 keys, one per row (just the key
 *      itself, e.g. HEBCAP-XXXX-XXXX-XXXX). Leave B, C, D empty - the
 *      script fills those in automatically.
 *      (If you already have a "Keys" tab from before, just add the new
 *      "DeviceId" header in D1 - your existing keys/rows are fine as is.)
 *
 *    Tab 2, named exactly: Usage
 *      Row 1 headers: A1=DeviceId   B1=SecondsUsed   C1=LastUpdated
 *      Leave the rest empty - the script creates one row per device
 *      automatically the first time it's seen.
 *
 * 3. In the Sheet: Extensions -> Apps Script.
 * 4. Delete whatever's in the code editor and paste this entire file in.
 * 5. Deploy (top right) -> New deployment (or "Manage deployments" ->
 *    the pencil/edit icon on an existing one, if you're upgrading from
 *    the earlier version and want to keep the same URL).
 *      - Gear icon next to "Select type" -> Web app.
 *      - Execute as: Me.
 *      - Who has access: Anyone.
 *      - Deploy, and authorize it once when asked.
 * 6. Copy the Web app URL (https://script.google.com/macros/s/.../exec)
 *    and paste it into LICENSE_SERVER_URL in js/main.js (search for that
 *    exact constant name), if it changed.
 *
 * To re-issue a key (e.g. a customer needs it moved to a new PC), just
 * clear that row's Used/UsedAt/DeviceId cells in the Keys sheet.
 * To reset a device's free trial, delete its row in the Usage sheet.
 */

var KEYS_SHEET_NAME = "Keys";
var COL_KEY = 1;       // column A
var COL_USED = 2;      // column B
var COL_USED_AT = 3;   // column C
var COL_DEVICE = 4;    // column D

var USAGE_SHEET_NAME = "Usage";
var COL_USAGE_DEVICE = 1;   // column A
var COL_USAGE_SECONDS = 2;  // column B
var COL_USAGE_UPDATED = 3;  // column C

function doGet(e) {
  var action = String(e.parameter.action || "activate"); // default keeps old links working
  var device = normalize_(e.parameter.device);

  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    if (action === "status") return handleStatus_(device);
    if (action === "record_usage") return handleRecordUsage_(device, e.parameter.seconds);
    return handleActivate_(device, normalize_(e.parameter.key));
  } finally {
    lock.releaseLock();
  }
}

// ---------- Keys (license activation) ----------

function handleActivate_(device, key) {
  if (!key) return respond_({ valid: false, reason: "missing_key" });

  var sheet = getSheet_(KEYS_SHEET_NAME);
  if (!sheet) return respond_({ valid: false, reason: "server_misconfigured" });

  var data = sheet.getDataRange().getValues();
  for (var row = 1; row < data.length; row++) { // row 0 is the header
    if (normalize_(data[row][COL_KEY - 1]) !== key) continue;

    var claimedBy = normalize_(data[row][COL_DEVICE - 1]);
    if (!claimedBy) {
      // Unclaimed - claim it for this device now.
      sheet.getRange(row + 1, COL_USED).setValue(true);
      sheet.getRange(row + 1, COL_USED_AT).setValue(new Date());
      sheet.getRange(row + 1, COL_DEVICE).setValue(device);
      return respond_({ valid: true });
    }
    if (claimedBy === device) {
      // Same device re-entering its own key (e.g. after reinstalling the
      // plugin) - still valid, not "already used" against themselves.
      return respond_({ valid: true });
    }
    return respond_({ valid: false, reason: "already_used" });
  }
  return respond_({ valid: false, reason: "not_found" });
}

// ---------- Usage (free trial tracking) ----------

function handleStatus_(device) {
  if (!device) return respond_({ usedSeconds: 0, licensed: false });
  return respond_({
    usedSeconds: getUsageSeconds_(device),
    licensed: deviceHasLicense_(device),
  });
}

function handleRecordUsage_(device, secondsParam) {
  if (!device) return respond_({ ok: false, reason: "missing_device" });
  var addSeconds = Number(secondsParam) || 0;
  var sheet = getSheet_(USAGE_SHEET_NAME);
  if (!sheet) return respond_({ ok: false, reason: "server_misconfigured" });

  var data = sheet.getDataRange().getValues();
  for (var row = 1; row < data.length; row++) {
    if (normalize_(data[row][COL_USAGE_DEVICE - 1]) === device) {
      var newTotal = (Number(data[row][COL_USAGE_SECONDS - 1]) || 0) + addSeconds;
      sheet.getRange(row + 1, COL_USAGE_SECONDS).setValue(newTotal);
      sheet.getRange(row + 1, COL_USAGE_UPDATED).setValue(new Date());
      return respond_({ ok: true, usedSeconds: newTotal });
    }
  }
  // First time seeing this device - add a new row.
  sheet.appendRow([device, addSeconds, new Date()]);
  return respond_({ ok: true, usedSeconds: addSeconds });
}

function getUsageSeconds_(device) {
  var sheet = getSheet_(USAGE_SHEET_NAME);
  if (!sheet) return 0;
  var data = sheet.getDataRange().getValues();
  for (var row = 1; row < data.length; row++) {
    if (normalize_(data[row][COL_USAGE_DEVICE - 1]) === device) {
      return Number(data[row][COL_USAGE_SECONDS - 1]) || 0;
    }
  }
  return 0;
}

function deviceHasLicense_(device) {
  var sheet = getSheet_(KEYS_SHEET_NAME);
  if (!sheet) return false;
  var data = sheet.getDataRange().getValues();
  for (var row = 1; row < data.length; row++) {
    if (normalize_(data[row][COL_DEVICE - 1]) === device) return true;
  }
  return false;
}

// ---------- shared helpers ----------

function getSheet_(name) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function normalize_(v) {
  return String(v || "").trim().toUpperCase();
}

function respond_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
