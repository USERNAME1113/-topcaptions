"""
caption_engine.py - local Hebrew transcription/captioning worker.

Takes an exported WAV file, runs it through faster-whisper with a
Hebrew-tuned ivrit-ai model, and writes a plain SRT. Two cue-splitting
modes:
  - smart split (default): groups words into cues that never cross a
    sentence boundary, and breaks at natural speech pauses within a
    sentence rather than any fixed word count. This matters specifically
    for Hebrew: splitting mid-sentence by a blind word count tends to
    produce ungrammatical breaks (severing a verb phrase from its
    object, gluing the tail of one clause to the start of an unrelated
    next one) - pausing where the speaker actually paused reads far more
    naturally, and a sentence end always forces a break regardless.
  - fixed word count (--words-per-line N): the older, simpler behavior -
    exactly N words per cue, with no awareness of sentence boundaries or
    speech pauses at all.
Optionally, with --no-commas, all punctuation (not just commas) is
stripped from the output text.

Communication contract (stdout, one JSON object per line, utf-8). Every
line has a "type" field:
  {"type": "step", "label": "load_model"}
  {"type": "step", "label": "transcribe"}
  {"type": "percent", "value": 42}
  {"type": "result", "srt": "...", "cues": 37}
  {"type": "failure", "detail": "..."}   then exit code 1
"""
import argparse
import json
import os
import re
import sys
from collections import namedtuple

# panel-friendly aliases -> Hugging Face repo ids (CTranslate2 format,
# required by faster-whisper). Both are Apache-2.0 licensed, free to use.
MODEL_ALIASES = {
    "ivrit-turbo": "ivrit-ai/whisper-large-v3-turbo-ct2",  # fast, good default
    "ivrit-large": "ivrit-ai/whisper-large-v3-ct2",        # slower, more accurate
}

# A cue is just (start, end, text) - built either straight from Whisper's own
# segments, from sentence-aware word grouping (smart split, default), or from
# fixed-size word grouping (--words-per-line). write_srt() only cares about
# these three fields, so it doesn't need to know which path produced them.
Cue = namedtuple("Cue", ["start", "end", "text"])


def emit(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def fail(detail):
    emit({"type": "failure", "detail": detail})
    sys.exit(1)


def fmt_ts(t):
    """Seconds (float) -> SRT timestamp HH:MM:SS,mmm."""
    if t is None or t < 0:
        t = 0.0
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


# --- Hebrew/bidi line direction -------------------------------------------
#
# NOTE: this used to wrap every Hebrew line in explicit Unicode RTL
# embedding marks (U+202B ... U+202C) to fix trailing-punctuation display
# issues in some players. That turned out to actively corrupt mixed
# Hebrew+number text instead (e.g. "1,500 שקלים" rendering mangled) - many
# consumers of the SRT (including Premiere/AE's own caption and text
# engines, which is what actually renders this content now) don't apply
# the full Unicode Bidirectional Algorithm to nested embedding the way a
# fully bidi-compliant browser would, so forcing an explicit embedding
# does more harm than good. Text is now passed through exactly as Whisper
# produced it, relying on the host app's native RTL text handling instead.


def strip_all_punctuation(text):
    """Remove sentence/clause punctuation - periods, commas, question
    marks, exclamation marks, colons, semicolons (both Latin and
    Hebrew/Arabic-style variants) - and tidy up the resulting double
    spaces. Used when the "no punctuation" option is enabled; leaves
    letters, numbers, and spacing otherwise untouched."""
    text = re.sub(r"[.,!?;:،؛]", "", text)
    return re.sub(r"\s{2,}", " ", text).strip()


# --- Numbers embedded in Hebrew text ---------------------------------------
#
# A plain number like "2.5" or "1,500" sitting inside a Hebrew (RTL) line
# can come out visually mangled ("-2. 5" instead of "2.5") when rendered by
# a caption/text engine that doesn't fully implement the Unicode
# Bidirectional Algorithm - Premiere's and After Effects' own caption/text
# renderers included, as it turns out (confirmed: this still happened even
# with no explicit direction-embedding characters in the SRT at all, so the
# renderer's own *implicit* bidi handling is what's misbehaving, not
# anything this project was adding). The correct, narrow fix is to mark
# just the numeric run itself as strongly left-to-right using LRM
# (U+200E, zero-width, invisible) - unlike wrapping the whole line in a
# strong RTL embedding (tried previously, and reverted because it broke
# other things), this only pins down the digits' own direction and leaves
# the surrounding Hebrew text's natural flow completely untouched.
NUMBER_RUN = re.compile(r"\d[\d,.:]*\d|\d")
LRM = "\u200E"  # LEFT-TO-RIGHT MARK


def stabilize_embedded_numbers(text):
    """Wrap every numeric run in `text` with LRM marks, so digit order
    stays correct even inside an RTL line, without touching anything else
    in the line."""
    return NUMBER_RUN.sub(lambda m: LRM + m.group(0) + LRM, text)


# Characters that end a sentence/clause in Hebrew (and generally). A cue
# break is always forced right after one of these, regardless of word count.
SENTENCE_ENDERS = set(".?!:;׃…")
# Closing quotes/brackets that can trail a sentence-ending mark (e.g. a
# quoted sentence ending in ". or ."), which would otherwise hide the
# real terminal punctuation from a naive "check the last character" test.
TRAILING_WRAPPERS = "\"')]»›\u201d\u2019"

# A gap this long (seconds) between two consecutive words is treated as a
# natural speech pause - a real clause boundary a person paused at while
# speaking - rather than normal inter-word timing within a fluent phrase.
NATURAL_PAUSE_SECONDS = 0.3

# Even with pause detection, some stretches of speech run on for a long
# time with no gap long enough to count as a pause and no sentence-ending
# punctuation in the middle (run-on sentences, lists, filler words like
# "אה" chained together) - without any ceiling at all, those became
# cues stuffed with far more words than anyone would want on screen at
# once. This forces a break once a cue reaches this many words, even
# without a detected pause - a true last resort, since natural pauses and
# sentence ends are checked first and almost always fire long before this.
MAX_WORDS_CEILING = 5


def is_sentence_ending_token(token):
    """True if `token` (a single word, as produced by Whisper) ends a
    sentence/clause - checking past any trailing closing quote or bracket
    so a quoted sentence like `שלום."` is still recognized correctly."""
    token = token.rstrip(TRAILING_WRAPPERS)
    return bool(token) and token[-1] in SENTENCE_ENDERS


def group_words_fixed(words, words_per_line):
    """Chunk a flat list of faster-whisper Word objects into groups of
    exactly `words_per_line`, with no regard for sentence boundaries. Used
    only when the smart-split default is explicitly turned off."""
    groups = []
    current = []
    for w in words:
        current.append(w)
        if len(current) >= words_per_line:
            groups.append(current)
            current = []
    if current:
        groups.append(current)
    return groups


def group_words_smart(words):
    """Chunk a flat list of faster-whisper Word objects into cues that
    never cross a sentence/clause boundary - and, within a sentence,
    break at natural speech pauses rather than an arbitrary word count.
    A gap between two consecutive words that's noticeably longer than a
    normal mid-sentence gap usually marks a real clause boundary (the
    kind a human would naturally pause at) - e.g. "היום אני הולך לקנות /
    משהו מהסופר" breaks after "לקנות" because that's where the speaker
    actually paused, not because some fixed word count was reached.
    MAX_WORDS_CEILING only kicks in as a last-resort safety net for the
    rare stretch with neither a pause nor sentence-ending punctuation for
    too long - it is not the primary driver of where breaks happen."""
    groups = []
    current = []
    for idx, w in enumerate(words):
        current.append(w)
        token = (w.word or "").strip()
        ends_sentence = is_sentence_ending_token(token)

        natural_pause = False
        if idx + 1 < len(words) and len(current) >= 2:
            gap = words[idx + 1].start - w.end
            if gap >= NATURAL_PAUSE_SECONDS:
                natural_pause = True

        hit_ceiling = len(current) >= MAX_WORDS_CEILING

        if ends_sentence or natural_pause or hit_ceiling:
            groups.append(current)
            current = []
    if current:
        groups.append(current)
    return groups


def write_srt(cues_in, out_path, strip_punctuation_flag=False):
    cues = 0
    with open(out_path, "w", encoding="utf-8") as f:
        for i, c in enumerate(cues_in, start=1):
            text = (c.text or "").strip()
            if strip_punctuation_flag:
                text = strip_all_punctuation(text)
            text = stabilize_embedded_numbers(text)
            if not text:
                continue
            f.write(f"{i}\n")
            f.write(f"{fmt_ts(c.start)} --> {fmt_ts(c.end)}\n")
            f.write(text + "\n\n")
            cues += 1
    return cues


def build_silence_cuts(speech_regions, duration, min_silence_seconds, padding_seconds):
    """Build safe internal non-speech ranges from Whisper/VAD speech segments.

    The resulting cuts deliberately exclude a short amount of audio at both
    sides of each detected pause. This prevents consonants at the boundary
    from being clipped when the VAD segment timing is slightly imprecise.
    Leading and trailing silence are left untouched, so the timeline keeps its
    original pickup and tail unless the editor removes them manually.
    """
    if duration <= 0 or not speech_regions:
        return []

    normalized = []
    for start, end in sorted(speech_regions):
        start = max(0.0, float(start))
        end = min(float(duration), float(end))
        if end <= start:
            continue
        if normalized and start <= normalized[-1][1]:
            normalized[-1] = (normalized[-1][0], max(normalized[-1][1], end))
        else:
            normalized.append((start, end))

    cuts = []
    for index in range(len(normalized) - 1):
        silence_start = normalized[index][1]
        silence_end = normalized[index + 1][0]
        if silence_end - silence_start < min_silence_seconds:
            continue
        cut_start = silence_start + padding_seconds
        cut_end = silence_end - padding_seconds
        if cut_end > cut_start:
            cuts.append({
                "start": round(cut_start, 6),
                "end": round(cut_end, 6),
                "duration": round(cut_end - cut_start, 6),
            })
    return cuts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--audio", required=True, help="path to the exported WAV file")
    ap.add_argument("--out", required=True, help="path to write the .srt file")
    ap.add_argument("--mode", default="captions", choices=["captions", "autocut"],
                    help="captions writes an SRT; autocut returns safe internal silence ranges")
    ap.add_argument("--model", default="ivrit-turbo", choices=list(MODEL_ALIASES.keys()))
    ap.add_argument("--model-dir", required=True, help="where models are downloaded/cached")
    ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--smart-split", action="store_true",
                     help="group cues by sentence boundary and natural speech pauses (default behavior)")
    ap.add_argument("--words-per-line", type=int, default=0,
                     help="fixed-size cues of N words; ignored when --smart-split is set (0 = whole Whisper segments)")
    ap.add_argument("--no-commas", action="store_true", help="strip all punctuation from the output text")
    ap.add_argument("--min-silence-ms", type=int, default=550,
                    help="minimum internal VAD pause considered for an automatic cut")
    ap.add_argument("--speech-padding-ms", type=int, default=80,
                    help="audio retained at each side of an automatic-cut boundary")
    args = ap.parse_args()

    if not os.path.isfile(args.audio):
        fail(f"קובץ אודיו לא נמצא: {args.audio}")

    os.makedirs(args.model_dir, exist_ok=True)
    repo_id = MODEL_ALIASES[args.model]

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        fail("faster-whisper לא מותקן. הריצו: pip install faster-whisper")
        return

    emit({"type": "step", "label": "load_model", "model": repo_id})

    # NOTE: "cuda" is deliberately NOT attempted for "auto" here. On Windows,
    # a missing/mismatched CUDA install (e.g. no cublas64_12.dll) makes
    # ctranslate2 hard-crash the process instead of raising a catchable
    # Python exception, so a try/except around it can't fall back safely -
    # the whole worker just dies. CPU is reliable everywhere and plenty
    # fast for this model size; GPU can be added back later as an explicit
    # opt-in once we can detect a working CUDA install first.
    device = args.device
    if device == "auto":
        device = "cpu"
    compute_type = "float16" if device == "cuda" else "int8"

    try:
        model = WhisperModel(repo_id, device=device, compute_type=compute_type,
                              download_root=args.model_dir)
    except Exception as e:
        fail(f"טעינת המודל נכשלה: {e}")
        return

    emit({"type": "step", "label": "transcribe"})

    if args.mode == "autocut":
        try:
            segments, info = model.transcribe(
                args.audio, language="he", beam_size=5, word_timestamps=False,
                vad_filter=True,
                vad_parameters=dict(min_silence_duration_ms=max(100, args.min_silence_ms))
            )
            total = float(info.duration or 0)
            speech_regions = []
            for seg in segments:
                start = float(getattr(seg, "start", 0) or 0)
                end = float(getattr(seg, "end", 0) or 0)
                if end > start:
                    speech_regions.append((start, end))
                if total > 0 and end > 0:
                    emit({"type": "percent", "value": min(99, int((end / total) * 100))})

            cuts = build_silence_cuts(
                speech_regions,
                total,
                max(0.1, args.min_silence_ms / 1000.0),
                max(0.0, args.speech_padding_ms / 1000.0),
            )
            emit({
                "type": "result",
                "mode": "autocut",
                "cuts": cuts,
                "duration": total,
                "speech_regions": len(speech_regions),
            })
            return
        except Exception as e:
            fail(f"ניתוח השקטים נכשל: {e}")
            return

    fixed_split = (not args.smart_split) and args.words_per_line and args.words_per_line > 0
    need_words = args.smart_split or fixed_split

    try:
        segments, info = model.transcribe(
            args.audio, language="he", beam_size=5, word_timestamps=need_words,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500)
        )
        total = info.duration or 0
        collected = []

        if need_words:
            all_words = []
            for seg in segments:
                if seg.words:
                    all_words.extend(seg.words)
                if total > 0 and seg.end:
                    pct = min(99, int((seg.end / total) * 100))
                    emit({"type": "percent", "value": pct})

            groups = group_words_smart(all_words) if args.smart_split else group_words_fixed(all_words, args.words_per_line)
            for group in groups:
                text = " ".join(w.word.strip() for w in group)
                collected.append(Cue(group[0].start, group[-1].end, text))
        else:
            for seg in segments:
                collected.append(Cue(seg.start, seg.end, seg.text))
                if total > 0:
                    pct = min(99, int((seg.end / total) * 100))
                    emit({"type": "percent", "value": pct})
    except Exception as e:
        fail(f"התמלול נכשל: {e}")
        return

    emit({"type": "step", "label": "write"})
    cues = write_srt(collected, args.out, strip_punctuation_flag=args.no_commas)

    # Always also write a plain JSON list of cues (start/end/text). Premiere
    # doesn't need this (it imports the .srt directly), but After Effects
    # has no native caption/subtitle import, so the panel builds text layers
    # itself from this file instead.
    cues_path = args.out + ".cues.json"
    with open(cues_path, "w", encoding="utf-8") as f:
        json.dump(
            [{"start": c.start, "end": c.end,
              "text": stabilize_embedded_numbers((strip_all_punctuation(c.text) if args.no_commas else c.text).strip())}
             for c in collected if (c.text or "").strip()],
            f, ensure_ascii=False
        )

    emit({
        "type": "result",
        "srt": args.out,
        "cues": cues,
        "cues_json": cues_path,
        "duration": total,
    })


if __name__ == "__main__":
    main()
