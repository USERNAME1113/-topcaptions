// update-manager.js - Isolated TopCaptions updater for Windows and macOS.
// This module intentionally has no dependency on captioning, cuts, licensing,
// timeline selection, or Adobe ExtendScript execution.
(function () {
    "use strict";

    var CURRENT_VERSION = "1.0.6";
    var MANIFEST_URL = "https://raw.githubusercontent.com/TOP-EDIT/topcaptions-updates/main/latest.json";
    var ALLOWED_DOWNLOAD_PREFIX = "https://raw.githubusercontent.com/TOP-EDIT/topcaptions-updates/main/";
    var REQUEST_TIMEOUT_MS = 30000;
    var notice;
    var updateInfo;

    function nodeModule(name) {
        try { return require(name); } catch (ignore) { return null; }
    }

    var https = nodeModule("https");
    var fs = nodeModule("fs");
    var path = nodeModule("path");
    var os = nodeModule("os");
    var crypto = nodeModule("crypto");
    var childProcess = nodeModule("child_process");
    var processRef = nodeModule("process");

    function platform() {
        return processRef ? processRef.platform : "";
    }

    function isWindows() { return platform() === "win32"; }
    function isMac() { return platform() === "darwin"; }
    function isSupportedPlatform() { return isWindows() || isMac(); }

    function parseVersion(value) {
        var match = String(value || "").match(/^(\d+)\.(\d+)\.(\d+)$/);
        if (!match) return null;
        return [Number(match[1]), Number(match[2]), Number(match[3])];
    }

    function isNewerVersion(remote, local) {
        var remoteParts = parseVersion(remote);
        var localParts = parseVersion(local);
        if (!remoteParts || !localParts) return false;
        for (var i = 0; i < 3; i++) {
            if (remoteParts[i] > localParts[i]) return true;
            if (remoteParts[i] < localParts[i]) return false;
        }
        return false;
    }

    function getPlatformPackage(manifest) {
        if (isWindows()) return manifest && manifest.windows;
        if (isMac()) return manifest && manifest.macos;
        return null;
    }

    function expectedExtension() {
        return isWindows() ? ".exe" : (isMac() ? ".zip" : "");
    }

    function safeManifest(data) {
        if (!data || data.product !== "TopCaptions") return false;
        if (!isNewerVersion(data.version, CURRENT_VERSION)) return false;

        var packageInfo = getPlatformPackage(data);
        var extension = expectedExtension();
        if (!packageInfo || !extension) return false;
        if (typeof packageInfo.filename !== "string" || !/^[A-Za-z0-9._-]+$/.test(packageInfo.filename)) return false;
        if (packageInfo.filename.toLowerCase().slice(-extension.length) !== extension) return false;
        if (typeof packageInfo.downloadUrl !== "string" || packageInfo.downloadUrl.indexOf(ALLOWED_DOWNLOAD_PREFIX) !== 0) return false;
        if (typeof packageInfo.sha256 !== "string" || !/^[a-f0-9]{64}$/i.test(packageInfo.sha256)) return false;
        return true;
    }

    function requestText(url, callback) {
        if (!https) return callback(new Error("Node HTTPS is unavailable"));
        var request = https.get(url, {
            headers: { "User-Agent": "TopCaptions-Updater/" + CURRENT_VERSION }
        }, function (response) {
            if (response.statusCode !== 200) {
                response.resume();
                return callback(new Error("Unexpected update manifest response: " + response.statusCode));
            }
            var body = "";
            response.setEncoding("utf8");
            response.on("data", function (chunk) { body += chunk; });
            response.on("end", function () { callback(null, body); });
        });
        request.setTimeout(REQUEST_TIMEOUT_MS, function () {
            request.destroy(new Error("Update manifest request timed out"));
        });
        request.on("error", callback);
    }

    function makeNotice() {
        if (notice) return notice;
        var host = document.getElementById("mainApp");
        if (!host) return null;

        notice = document.createElement("section");
        notice.id = "topCaptionsUpdateNotice";
        notice.className = "update-notice hidden";
        notice.setAttribute("role", "status");
        notice.setAttribute("aria-live", "polite");

        var title = document.createElement("strong");
        title.id = "topCaptionsUpdateTitle";
        notice.appendChild(title);

        var text = document.createElement("span");
        text.id = "topCaptionsUpdateText";
        notice.appendChild(text);

        var button = document.createElement("button");
        button.id = "topCaptionsUpdateButton";
        button.type = "button";
        button.className = "btn-secondary update-notice-button";
        button.textContent = "התקן עדכון";
        button.addEventListener("click", startUpdate);
        notice.appendChild(button);

        var status = document.createElement("small");
        status.id = "topCaptionsUpdateStatus";
        notice.appendChild(status);

        var tabBar = host.querySelector(".feature-tabs");
        if (tabBar && tabBar.parentNode) tabBar.parentNode.insertBefore(notice, tabBar);
        else host.insertBefore(notice, host.firstChild);
        return notice;
    }

    function setStatus(text, isError) {
        if (!notice) return;
        var status = document.getElementById("topCaptionsUpdateStatus");
        if (!status) return;
        status.className = isError ? "error" : "";
        status.textContent = text || "";
    }

    function showAvailable(manifest) {
        var box = makeNotice();
        if (!box) return;
        updateInfo = manifest;
        document.getElementById("topCaptionsUpdateTitle").textContent = "עדכון זמין";
        document.getElementById("topCaptionsUpdateText").textContent = "גרסה " + manifest.version + " מוכנה להתקנה.";
        document.getElementById("topCaptionsUpdateButton").disabled = false;
        setStatus("העדכון יורד רק לאחר לחיצה שלך.", false);
        box.className = "update-notice";
    }

    function downloadAndVerify(manifest, callback) {
        if (!https || !fs || !path || !os || !crypto) return callback(new Error("רכיבי העדכון המקומיים אינם זמינים."));
        var packageInfo = getPlatformPackage(manifest);
        if (!packageInfo || packageInfo.downloadUrl.indexOf(ALLOWED_DOWNLOAD_PREFIX) !== 0) {
            return callback(new Error("כתובת העדכון אינה מאושרת."));
        }

        var destination = path.join(os.tmpdir(), "TopCaptions-Setup-" + manifest.version + "-" + Date.now() + expectedExtension());
        var completed = false;
        function finish(error, filePath) {
            if (completed) return;
            completed = true;
            callback(error, filePath);
        }

        var request = https.get(packageInfo.downloadUrl, {
            headers: { "User-Agent": "TopCaptions-Updater/" + CURRENT_VERSION }
        }, function (response) {
            if (response.statusCode !== 200) {
                response.resume();
                return finish(new Error("לא ניתן להוריד את העדכון (" + response.statusCode + ")."));
            }

            var hash = crypto.createHash("sha256");
            var output = fs.createWriteStream(destination);
            response.on("data", function (chunk) { hash.update(chunk); });
            response.on("error", function (error) {
                try { output.close(); } catch (ignore) {}
                try { fs.unlinkSync(destination); } catch (ignoreDelete) {}
                finish(error);
            });
            output.on("error", function (error) {
                try { fs.unlinkSync(destination); } catch (ignoreDelete) {}
                finish(error);
            });
            output.on("finish", function () {
                output.close(function () {
                    var actualHash = hash.digest("hex").toLowerCase();
                    if (actualHash !== String(packageInfo.sha256).toLowerCase()) {
                        try { fs.unlinkSync(destination); } catch (ignoreDelete) {}
                        return finish(new Error("בדיקת אבטחה נכשלה: קובץ העדכון אינו תואם לגרסה שפורסמה."));
                    }
                    finish(null, destination);
                });
            });
            response.pipe(output);
        });
        request.setTimeout(REQUEST_TIMEOUT_MS, function () {
            request.destroy(new Error("הורדת העדכון נמשכה זמן רב מדי."));
        });
        request.on("error", finish);
    }

    function startWindowsInstallerWhenAdobeCloses(installerPath, callback) {
        var scriptPath = path.join(os.tmpdir(), "topcaptions-run-update-" + Date.now() + ".cmd");
        var safeInstallerPath = String(installerPath).replace(/"/g, "");
        var script = [
            "@echo off",
            "setlocal",
            ":wait_for_adobe",
            "tasklist /FI \"IMAGENAME eq Adobe Premiere Pro.exe\" 2>NUL | find /I \"Adobe Premiere Pro.exe\" >NUL",
            "if not errorlevel 1 (timeout /t 2 /nobreak >NUL & goto wait_for_adobe)",
            "tasklist /FI \"IMAGENAME eq AfterFX.exe\" 2>NUL | find /I \"AfterFX.exe\" >NUL",
            "if not errorlevel 1 (timeout /t 2 /nobreak >NUL & goto wait_for_adobe)",
            "start \"\" \"" + safeInstallerPath + "\"",
            "del \"%~f0\""
        ].join("\r\n");

        try {
            fs.writeFileSync(scriptPath, script, "utf8");
            var child = childProcess.spawn("cmd.exe", ["/c", scriptPath], {
                detached: true,
                stdio: "ignore",
                windowsHide: true
            });
            child.unref();
            callback(null);
        } catch (error) {
            try { fs.unlinkSync(scriptPath); } catch (ignoreDelete) {}
            callback(error);
        }
    }

    function shellQuote(value) {
        return "'" + String(value).replace(/'/g, "'\\''") + "'";
    }

    function startMacInstallerWhenAdobeCloses(archivePath, version, callback) {
        var workDir = path.join(os.tmpdir(), "topcaptions-update-" + version + "-" + Date.now());
        var scriptPath = path.join(workDir, "run-update.sh");
        var extractDir = path.join(workDir, "extracted");
        var installerPath = path.join(extractDir, "TopCaptions", "install_topcaptions_macos.command");
        var script = [
            "#!/bin/sh",
            "set -eu",
            "while pgrep -x 'Adobe Premiere Pro' >/dev/null 2>&1 || pgrep -x 'After Effects' >/dev/null 2>&1; do sleep 2; done",
            "mkdir -p " + shellQuote(extractDir),
            "/usr/bin/ditto -x -k " + shellQuote(archivePath) + " " + shellQuote(extractDir),
            "INSTALLER=" + shellQuote(installerPath),
            "if [ ! -f \"$INSTALLER\" ]; then exit 1; fi",
            "/bin/chmod 755 \"$INSTALLER\"",
            "/usr/bin/open -a Terminal \"$INSTALLER\"",
            "rm -f \"$0\""
        ].join("\n");

        try {
            fs.mkdirSync(workDir, { recursive: true });
            fs.writeFileSync(scriptPath, script, "utf8");
            fs.chmodSync(scriptPath, 0o700);
            var child = childProcess.spawn("/bin/sh", [scriptPath], {
                detached: true,
                stdio: "ignore"
            });
            child.unref();
            callback(null);
        } catch (error) {
            try { fs.unlinkSync(scriptPath); } catch (ignoreDelete) {}
            callback(error);
        }
    }

    function startInstallerWhenAdobeCloses(installerPath, version, callback) {
        if (!fs || !path || !childProcess || !os) return callback(new Error("לא ניתן להפעיל את מתקין העדכון."));
        if (isWindows()) return startWindowsInstallerWhenAdobeCloses(installerPath, callback);
        if (isMac()) return startMacInstallerWhenAdobeCloses(installerPath, version, callback);
        callback(new Error("מערכת ההפעלה אינה נתמכת לעדכון אוטומטי."));
    }

    function startUpdate() {
        if (!updateInfo || !isSupportedPlatform()) return;
        var button = document.getElementById("topCaptionsUpdateButton");
        if (button) button.disabled = true;
        setStatus("מוריד ובודק את העדכון…", false);

        downloadAndVerify(updateInfo, function (error, installerPath) {
            if (error) {
                if (button) button.disabled = false;
                return setStatus(error.message || "לא ניתן להשלים את הורדת העדכון.", true);
            }
            startInstallerWhenAdobeCloses(installerPath, updateInfo.version, function (launchError) {
                if (launchError) {
                    if (button) button.disabled = false;
                    return setStatus(launchError.message || "לא ניתן להכין את ההתקנה.", true);
                }
                if (button) button.disabled = true;
                if (isMac()) {
                    setStatus("העדכון מוכן. סגרו את Premiere Pro או After Effects; מתקין macOS ייפתח אוטומטית לאחר הסגירה.", false);
                } else {
                    setStatus("העדכון מוכן. סגרו את Premiere Pro או After Effects; ההתקנה תתחיל אוטומטית לאחר הסגירה.", false);
                }
            });
        });
    }

    function checkForUpdate() {
        if (!isSupportedPlatform() || !https || !fs || !path || !os || !crypto || !childProcess) return;
        requestText(MANIFEST_URL, function (error, body) {
            if (error) return; // Network errors are non-blocking and deliberately silent.
            try {
                var manifest = JSON.parse(body);
                if (safeManifest(manifest)) showAvailable(manifest);
            } catch (ignore) {}
        });
    }

    window.TopCaptionsAutoUpdater = {
        checkForUpdate: checkForUpdate,
        currentVersion: CURRENT_VERSION
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", checkForUpdate);
    else checkForUpdate();
})();
