// autocut.js - TopCaptions automatic silence-cut workflow for Premiere Pro.
// Exports the active sequence audio, asks the local caption worker for safe
// non-speech ranges, then passes those ranges to jsx/autocut.jsx for a single,
// undoable ripple-delete operation.

(function () {
    "use strict";

    var cs = new CSInterface();
    var fs = require("fs");
    var path = require("path");
    var os = require("os");
    var childProcess = require("child_process");
    var isRunning = false;

    function byId(id) {
        return document.getElementById(id);
    }

    function hostName() {
        try {
            return (cs.getHostEnvironment().appName || "").toUpperCase();
        } catch (e) {
            return "";
        }
    }

    function setStatus(message, kind) {
        var status = byId("autoCutStatus");
        if (!status) return;
        status.textContent = message;
        status.className = "autocut-status " + (kind || "");
    }

    function appendLog(message, kind) {
        var log = byId("log");
        if (!log) return;
        var line = document.createElement("div");
        line.className = "line " + (kind || "dim");
        line.textContent = message;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
    }

    function setBusy(busy) {
        isRunning = busy;
        var button = byId("autoCutBtn");
        if (button) {
            button.disabled = busy;
            button.textContent = busy ? "מעבד חיתוכים אוטומטיים…" : "הסר שקטים אוטומטית";
        }
    }

    function evaluate(script) {
        return new Promise(function (resolve) {
            cs.evalScript(script, function (result) {
                var parsed = null;
                try { parsed = JSON.parse(result); } catch (e) {}
                resolve({ raw: result, json: parsed });
            });
        });
    }

    function hostArgument(value) {
        return JSON.stringify(value);
    }

    function licenceManager() {
        return window.TopCaptionsLicense || null;
    }

    async function ensureSharedTrialIsAvailable() {
        var manager = licenceManager();
        if (!manager) {
            throw new Error("מנגנון הרישיון לא נטען. סגרו ופתחו מחדש את הפאנל.");
        }
        await manager.refresh();
        var state = manager.getState();
        if (!state.licensed && !manager.canStartTrial()) {
            manager.showGate();
            return null;
        }
        return state;
    }

    function recordSharedTrialUsage(seconds) {
        var manager = licenceManager();
        if (!manager || !seconds || seconds <= 0) return;
        var state = manager.getState();
        if (!state.licensed) manager.recordUsage(seconds);
    }

    function capRangeByTrial(range, state) {
        if (!range || state.licensed) return range;
        var remaining = Math.max(0, Math.floor(Number(state.remainingSeconds) || 0));
        if (remaining <= 0 || range.durationSecs <= remaining) return range;
        return Object.assign({}, range, {
            endSecs: Number(range.startSecs) + remaining,
            durationSecs: remaining,
            isTrialCapped: true,
            exportInOut: true
        });
    }

    function waitForFile(filePath, timeoutMs) {
        return new Promise(function (resolve, reject) {
            var started = Date.now();
            var lastSize = -1;
            var stableChecks = 0;
            var timer = setInterval(function () {
                try {
                    if (fs.existsSync(filePath)) {
                        var size = fs.statSync(filePath).size;
                        if (size > 1000) {
                            stableChecks = (size === lastSize) ? stableChecks + 1 : 0;
                            lastSize = size;
                            if (stableChecks >= 2) {
                                clearInterval(timer);
                                resolve();
                                return;
                            }
                        }
                    }
                } catch (e) {}
                if (Date.now() - started >= timeoutMs) {
                    clearInterval(timer);
                    reject(new Error("קובץ האודיו לא הושלם בזמן. בדקו את הגדרות הייצוא (.epr) ונסו שוב."));
                }
            }, 750);
        });
    }

    function getWorkerSettings() {
        var pythonInput = byId("pythonExe");
        var modelDirInput = byId("modelDir");
        var modelInput = byId("modelSelect");
        var presetInput = byId("presetPath");
        var minSilenceInput = byId("autoCutMinSilence");
        var paddingInput = byId("autoCutPadding");

        var pythonExe = pythonInput ? pythonInput.value.trim() : "";
        var modelDir = modelDirInput ? modelDirInput.value.trim() : "";
        if (!pythonExe) throw new Error("יש להגדיר נתיב Python בהגדרות המתקדמות לפני הפעלת החיתוכים האוטומטיים.");
        if (!modelDir) throw new Error("יש להגדיר את מיקום קבצי מנוע הזיהוי בהגדרות המתקדמות לפני הפעלת החיתוכים האוטומטיים.");

        return {
            pythonExe: pythonExe,
            modelDir: modelDir,
            model: modelInput ? modelInput.value : "ivrit-turbo",
            presetPath: presetInput ? presetInput.value.trim() : "",
            minSilenceMs: Math.max(200, parseInt(minSilenceInput ? minSilenceInput.value : "550", 10) || 550),
            paddingMs: Math.max(0, parseInt(paddingInput ? paddingInput.value : "80", 10) || 80)
        };
    }

    function runWorker(settings, audioPath, resultPath, onProgress) {
        return new Promise(function (resolve, reject) {
            var extensionPath = cs.getSystemPath(SystemPath.EXTENSION);
            var workerPath = path.join(extensionPath, "backend", "caption_engine.py");
            var args = [
                workerPath,
                "--audio", audioPath,
                "--out", resultPath,
                "--mode", "autocut",
                "--model", settings.model,
                "--model-dir", settings.modelDir,
                "--min-silence-ms", String(settings.minSilenceMs),
                "--speech-padding-ms", String(settings.paddingMs)
            ];
            var worker;
            try {
                worker = childProcess.spawn(settings.pythonExe, args, {
                    windowsHide: true,
                    env: Object.assign({}, process.env, { PYTHONIOENCODING: "utf-8", PYTHONUTF8: "1" })
                });
            } catch (e) {
                reject(new Error("לא ניתן להפעיל את מנוע הניתוח: " + e.message));
                return;
            }

            var output = "";
            var stderr = "";
            var result = null;
            function consume(chunk) {
                output += chunk.toString("utf8");
                var lines = output.split(/\r?\n/);
                output = lines.pop();
                lines.forEach(function (line) {
                    if (!line) return;
                    try {
                        var event = JSON.parse(line);
                        if (event.type === "percent" && typeof event.value === "number") {
                            onProgress("מזהה אזורי שקט… " + event.value + "%");
                        } else if (event.type === "step") {
                            onProgress(event.label === "load_model" ? "טוען את מנוע הזיהוי…" : "מנתח את רצף האודיו…");
                        } else if (event.type === "result") {
                            result = event;
                        } else if (event.type === "failure") {
                            stderr += event.detail || "ניתוח השקטים נכשל.";
                        }
                    } catch (e) {
                        stderr += line + "\n";
                    }
                });
            }
            worker.stdout.on("data", consume);
            worker.stderr.on("data", function (chunk) { stderr += chunk.toString("utf8"); });
            worker.on("error", function (e) { reject(new Error("הפעלת מנוע הניתוח נכשלה: " + e.message)); });
            worker.on("close", function (code) {
                if (code !== 0 || !result) {
                    reject(new Error((stderr || "מנוע ניתוח השקטים הסתיים ללא תוצאה.").trim()));
                    return;
                }
                resolve(result);
            });
        });
    }

    function cleanup(paths) {
        paths.forEach(function (filePath) {
            try { if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (e) {}
        });
    }

    async function runAutomaticCuts() {
        if (isRunning) return;
        if (hostName() !== "PPRO") {
            setStatus("החיתוכים האוטומטיים זמינים רק ב־Premiere Pro.", "err");
            return;
        }

        var temporaryAudio = "";
        var temporaryResult = "";
        try {
            var trialState = await ensureSharedTrialIsAvailable();
            if (!trialState) return;
            var settings = getWorkerSettings();
            setBusy(true);
            setStatus(trialState.licensed ? "בודק את הרצף הפעיל…" : "בודק את הרצף הפעיל במסגרת הניסיון המשותף…", "");

            var capturedRange = window.TopCaptionsOperationRange || null;
            if (!capturedRange) {
                var timelineRange = await evaluate("hcGetTimelineRange()");
                if (!timelineRange.json || !timelineRange.json.ok) {
                    throw new Error((timelineRange.json && timelineRange.json.error) || "לא ניתן לקרוא את טווח הטיימליין הפעיל.");
                }
                capturedRange = capRangeByTrial(timelineRange.json, trialState);
            }
            if (capturedRange.isTrialCapped) {
                setStatus("מנתח רק את יתרת הניסיון הזמינה בטווח שנבחר…", "");
            } else if (capturedRange.hasInOut) {
                setStatus("מנתח רק את טווח In/Out שסומן בטיימליין…", "");
            } else {
                setStatus("לא סומן In/Out — מנתח את כל הרצף הפעיל…", "");
            }

            var stamp = Date.now();
            temporaryAudio = path.join(os.tmpdir(), "topcaptions-autocut-" + stamp + ".wav");
            temporaryResult = path.join(os.tmpdir(), "topcaptions-autocut-" + stamp + ".json");
            setStatus("מייצא אודיו מהרצף הפעיל…", "");
            var exportResult = await evaluate(
                "hcExportDirect(" + hostArgument(temporaryAudio) + "," + hostArgument(settings.presetPath) + "," + hostArgument(JSON.stringify(capturedRange)) + ")"
            );
            if (!exportResult.json || !exportResult.json.ok) {
                throw new Error((exportResult.json && exportResult.json.error) || "ייצוא האודיו מפרמייר נכשל.");
            }
            await waitForFile(temporaryAudio, 180000);

            var analysis = await runWorker(settings, temporaryAudio, temporaryResult, function (message) {
                setStatus(message, "");
            });
            var cuts = analysis.cuts || [];
            if (!cuts.length) {
                setStatus("לא נמצאו שקטים פנימיים המתאימים לחיתוך.", "ok");
                appendLog("חיתוכים אוטומטיים: לא נמצאו שקטים פנימיים מתאימים.", "dim");
                return;
            }

            var totalSeconds = cuts.reduce(function (sum, cut) { return sum + (Number(cut.duration) || 0); }, 0);
            setStatus("מחיל " + cuts.length + " חיתוכים על הטיימליין…", "");
            var applyPayload = { cuts: cuts, videoTracks: true, cutMethod: "batch", workArea: "range" };
            var applyResult = await evaluate(
                "hcApplySilenceCutsToSelection(" + hostArgument(JSON.stringify(applyPayload)) + "," + hostArgument(JSON.stringify(capturedRange)) + ")"
            );
            if (!applyResult.json || !applyResult.json.ok) {
                throw new Error((applyResult.json && applyResult.json.error) || "החלת החיתוכים על הטיימליין נכשלה.");
            }

            var applied = applyResult.json.appliedCuts || cuts.length;
            // The same duration accounting used by captions is applied here.
            // The server owns the per-device total, so reinstalling does not
            // create another five-minute allowance.
            recordSharedTrialUsage(Number(analysis.duration) || 0);
            setStatus("הושלמו " + applied + " חיתוכים ונחסכו " + totalSeconds.toFixed(1) + " שניות.", "ok");
            appendLog("חיתוכים אוטומטיים: " + applied + " אזורי שקט הוסרו (" + totalSeconds.toFixed(1) + " שניות). אפשר לבטל בפעולת Undo אחת.", "ok");
            window.dispatchEvent(new Event("topcaptions:trial-usage-recorded"));
        } catch (e) {
            var message = e && e.message ? e.message : String(e);
            setStatus(message, "err");
            appendLog("חיתוכים אוטומטיים נכשלו: " + message, "err");
        } finally {
            cleanup([temporaryAudio, temporaryResult]);
            setBusy(false);
        }
    }

    function initialise() {
        var panel = byId("cutsPanel") || byId("autoCutPanel");
        var button = byId("autoCutBtn");
        if (!panel || !button) return;
        if (hostName() !== "PPRO") {
            panel.classList.add("hidden");
            return;
        }
        button.addEventListener("click", runAutomaticCuts);
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialise);
    else initialise();
})();
