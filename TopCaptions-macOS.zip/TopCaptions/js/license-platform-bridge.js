/*
 * license-platform-bridge.js
 *
 * Loaded before the existing licensing module. It keeps the existing trial,
 * UI and processing logic intact while routing its licensing HTTP calls to
 * the configured Apps Script service and normalizing the device identifier
 * on macOS. No caption or automatic-cut algorithm is changed here.
 */
(function () {
    "use strict";

    var LICENSE_ENDPOINT = "https://script.google.com/macros/s/AKfycby1OxN-vKH-OfLeCnMt-oAciDJ3YqQWimm5EkNYCcHrn-8ziUvGkTUn_Pp06pY6c6fQ/exec";
    var originalFetch = window.fetch;

    function isMac() {
        try { return typeof process !== "undefined" && process.platform === "darwin"; }
        catch (e) { return false; }
    }

    function macDeviceId() {
        try {
            var childProcess = require("child_process");
            var output = childProcess.execFileSync(
                "/usr/sbin/ioreg",
                ["-rd1", "-c", "IOPlatformExpertDevice"],
                { encoding: "utf8", timeout: 3000 }
            );
            var match = output.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/i);
            if (match && match[1]) return "MAC-" + String(match[1]).toUpperCase();
        } catch (e) { /* fall through to a persistent local fallback */ }

        try {
            var key = "topcaptions_macos_device_id";
            var existing = window.localStorage.getItem(key);
            if (existing) return existing;
            var generated = "MAC-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 14).toUpperCase();
            window.localStorage.setItem(key, generated);
            return generated;
        } catch (e2) {
            return "MAC-UNAVAILABLE";
        }
    }

    function isLicenseRequest(parsedUrl) {
        var query = parsedUrl.search || "";
        return /(?:[?&](?:action=status|action=record_usage|key=|device=))/i.test(query);
    }

    function rewrittenLicenseUrl(input) {
        var source = String(input || "");
        var parsed;
        try { parsed = new URL(source, window.location.href); }
        catch (e) { return null; }
        if (!isLicenseRequest(parsed)) return null;

        var target = new URL(LICENSE_ENDPOINT);
        parsed.searchParams.forEach(function (value, name) {
            target.searchParams.set(name, value);
        });
        if (isMac()) target.searchParams.set("device", macDeviceId());
        return target.toString();
    }

    window.TopCaptionsLicenseEndpoint = LICENSE_ENDPOINT;
    window.TopCaptionsMacDeviceId = isMac() ? macDeviceId() : null;

    if (typeof originalFetch !== "function") return;
    window.fetch = function (input, init) {
        var rewritten = rewrittenLicenseUrl(input);
        return originalFetch.call(window, rewritten || input, init);
    };
})();
