// panel-tabs.js - presentation-only navigation and shared-trial status.
// It does not alter caption or automatic-cut processing logic.

(function () {
    "use strict";

    function byId(id) {
        return document.getElementById(id);
    }

    function formatTime(seconds) {
        seconds = Math.max(0, Math.round(Number(seconds) || 0));
        var minutes = Math.floor(seconds / 60);
        return minutes + ":" + String(seconds % 60).padStart(2, "0");
    }

    function setActiveTab(name) {
        var captionsTab = byId("tabCaptions");
        var cutsTab = byId("tabCuts");
        var captionsPanel = byId("captionsPanel");
        var cutsPanel = byId("cutsPanel");
        var showCaptions = name !== "cuts";

        captionsTab.classList.toggle("active", showCaptions);
        cutsTab.classList.toggle("active", !showCaptions);
        captionsTab.setAttribute("aria-selected", String(showCaptions));
        cutsTab.setAttribute("aria-selected", String(!showCaptions));
        captionsPanel.classList.toggle("hidden", !showCaptions);
        cutsPanel.classList.toggle("hidden", showCaptions);
    }

    var activeLicenceNoticeTimer = null;

    async function renderSharedTrialStatus() {
        var status = byId("sharedTrialStatus");
        var timerBadge = byId("trialTimerBadge");
        var manager = window.TopCaptionsLicense;
        if (!status || !manager) return;

        try {
            await manager.refresh();
            var state = manager.getState();
            status.classList.remove("hidden");
            if (activeLicenceNoticeTimer) {
                clearTimeout(activeLicenceNoticeTimer);
                activeLicenceNoticeTimer = null;
            }
            if (state.licensed) {
                if (timerBadge) {
                    timerBadge.textContent = "";
                    timerBadge.classList.add("hidden");
                }
                status.className = "shared-trial-status licensed";
                status.textContent = "הרישיון פעיל. גישה מלאה לכתוביות ולקאטים.";
                activeLicenceNoticeTimer = setTimeout(function () {
                    status.textContent = "";
                    status.classList.add("hidden");
                }, 10000);
                return;
            }
            if (timerBadge) {
                timerBadge.textContent = "ניסיון חינם: נשארו " + formatTime(state.remainingSeconds) + " מתוך " + formatTime(state.trialLimitSeconds);
                timerBadge.classList.remove("hidden");
            }
            status.className = "shared-trial-status";
            status.textContent = "ניסיון משותף לכתוביות ולקאטים: נשארו " +
                formatTime(state.remainingSeconds) + " מתוך " + formatTime(state.trialLimitSeconds);
        } catch (e) {
            if (timerBadge) timerBadge.classList.add("hidden");
            status.className = "shared-trial-status muted";
            status.textContent = "לא ניתן לעדכן כרגע את מצב הניסיון.";
        }
    }

    function initialise() {
        var captionsTab = byId("tabCaptions");
        var cutsTab = byId("tabCuts");
        if (!captionsTab || !cutsTab) return;

        captionsTab.addEventListener("click", function () { setActiveTab("captions"); });
        cutsTab.addEventListener("click", function () { setActiveTab("cuts"); });
        window.addEventListener("topcaptions:trial-usage-recorded", function () {
            setTimeout(renderSharedTrialStatus, 500);
        });
        setActiveTab("captions");
        setTimeout(renderSharedTrialStatus, 0);
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialise);
    else initialise();
})();
