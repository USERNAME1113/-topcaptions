// selection-guard.js - Timeline In/Out preflight and shared-trial cap.
// It deliberately leaves the caption and automatic-cut engines unchanged.

(function () {
    "use strict";

    var cs = new CSInterface();

    function byId(id) {
        return document.getElementById(id);
    }

    function isPremiere() {
        try { return (cs.getHostEnvironment().appName || "").toUpperCase() === "PPRO"; }
        catch (e) { return false; }
    }

    function evaluate(script) {
        return new Promise(function (resolve) {
            cs.evalScript(script, function (result) {
                var parsed = null;
                try { parsed = JSON.parse(result); } catch (e) {}
                resolve(parsed);
            });
        });
    }

    function showNotice(message, kind) {
        var notice = byId("selectionNotice");
        if (!notice) return;
        notice.className = "selection-notice " + (kind || "err");
        notice.textContent = message;
    }

    function clearNotice() {
        var notice = byId("selectionNotice");
        if (!notice) return;
        notice.className = "selection-notice hidden";
        notice.textContent = "";
    }

    function formatTime(totalSeconds) {
        var value = Math.max(0, Math.floor(Number(totalSeconds) || 0));
        return Math.floor(value / 60) + ":" + String(value % 60).padStart(2, "0");
    }

    async function capRangeToTrial(range) {
        var manager = window.TopCaptionsLicense;
        if (!manager) throw new Error("מנגנון הרישיון לא נטען. סגרו ופתחו מחדש את הפאנל.");
        await manager.refresh();
        var state = manager.getState();
        if (state.licensed) return range;

        var remaining = Math.max(0, Math.floor(Number(state.remainingSeconds) || 0));
        if (remaining <= 0 || !manager.canStartTrial()) {
            manager.showGate();
            return false;
        }
        if (range.durationSecs <= remaining) return range;

        var limited = Object.assign({}, range, {
            endSecs: range.startSecs + remaining,
            durationSecs: remaining,
            isTrialCapped: true,
            exportInOut: true
        });
        return limited;
    }

    async function validateTimelineRange() {
        var response = await evaluate("hcGetTimelineRange()");
        if (!response || !response.ok) {
            showNotice(
                (response && response.error) || "לא ניתן לקרוא את טווח הטיימליין. ודאו שיש רצף פעיל ב־Premiere ונסו שוב.",
                "err"
            );
            return false;
        }

        var range = await capRangeToTrial(response);
        if (!range) return false;

        if (range.isTrialCapped) {
            showNotice(
                "יתרת הניסיון היא " + formatTime(range.durationSecs) + ". הפעולה תחול על " +
                formatTime(range.durationSecs) + " הראשונות של הטווח בלבד.",
                "warn"
            );
        } else if (range.hasInOut) {
            showNotice(
                "טווח In/Out נבחר: הפעולה תחול רק בין נקודת ההתחלה לנקודת הסיום שסימנתם.",
                "ok"
            );
        } else {
            showNotice(
                "לא סומן טווח In/Out. הפעולה תחול על כל הרצף הפעיל. כדי לעבד חלק בלבד, סמנו In ו־Out בטיימליין ואז לחצו שוב.",
                "warn"
            );
        }
        return range;
    }

    async function armCaptionRange(range) {
        var response = await evaluate(
            "hcSetPendingCaptionRange(" + JSON.stringify(JSON.stringify(range)) + ")"
        );
        if (!response || !response.ok) {
            showNotice(
                (response && response.error) || "לא ניתן לשמור את טווח הטיימליין עבור הכתוביות. נסו שוב.",
                "err"
            );
            return false;
        }
        return true;
    }

    function protectButton(button) {
        var bypassOneClick = false;
        button.addEventListener("click", function (event) {
            if (!isPremiere() || bypassOneClick) {
                bypassOneClick = false;
                return;
            }
            event.preventDefault();
            event.stopImmediatePropagation();
            if (button.disabled) return;
            button.disabled = true;
            validateTimelineRange().then(async function (range) {
                button.disabled = false;
                if (!range) return;
                window.TopCaptionsOperationRange = range;
                if (button.id === "transcribeBtn" && !(await armCaptionRange(range))) return;

                // The range has now been captured for this job. Do not leave a
                // preflight-only notice visible during or after completion.
                clearNotice();
                bypassOneClick = true;
                button.click();
            }).catch(function () {
                button.disabled = false;
                showNotice("לא ניתן לאמת את טווח הטיימליין. ודאו ש־Premiere פתוח עם רצף פעיל ונסו שוב.", "err");
            });
        }, true);
    }

    function initialise() {
        var captionsButton = byId("transcribeBtn");
        var cutsButton = byId("autoCutBtn");
        if (captionsButton) protectButton(captionsButton);
        if (cutsButton) protectButton(cutsButton);
    }

    window.TopCaptionsTimelineRange = {
        validate: validateTimelineRange,
        clearNotice: clearNotice
    };

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", initialise);
    else initialise();
})();
